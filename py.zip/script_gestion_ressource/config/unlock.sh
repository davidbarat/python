ADM_CONFIG=`dirname $0`
LOCK_FILE=$ADM_CONFIG/config.lock

rm $LOCK_FILE
