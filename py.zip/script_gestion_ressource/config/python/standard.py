# standard.py : default settings for jython adminweb config scripts


# WAS version
prm_WAS_VERSION="7.0"
prm_WAS_VERSION_NUM=""

prm_WAS_EDITION="ND"

# ******************** SYSTEM PARAMETERS (DO NOT MODIFY)
prm_version="6.5"

prm_dmgrInstallRoot="/apps/WebSphere/profiles7/dmgr"
