

fullSync=${PYTHON_DIR_FUNCTIONS}/fullSync.py

$DMGR_HOME/bin/wsadmin.sh -lang jython -f ${fullSync}


