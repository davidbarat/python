DIR_NAME=$(cd -P $(dirname $0); pwd)

jaclFile="${DIR_NAME}/fullSync.jacl"

echo "Launch : $DMGR_DIR/bin/wsadmin.sh -lang jacl -f $jaclFile"
$DMGR_DIR/bin/wsadmin.sh -lang jacl -f $jaclFile


