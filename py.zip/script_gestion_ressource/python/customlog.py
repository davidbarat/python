import sys
import java
from java.util.logging import Logger, StreamHandler, Formatter, Level


class MyStreamHandler(StreamHandler):
    def publish(self, record):
        StreamHandler.publish(self, record)
        StreamHandler.flush(self)


class MyFormatter(Formatter):
    def format(self, record):
        log = (
            "[" + record.getLevel().toString() + " : "
            + record.getLoggerName() + "] "
            + record.getMessage() + "\n"
            )
        return log


def define_logger(name, level):
    logger = Logger.getLogger(name)
    logger.setLevel(Level.FINEST)
    sh = MyStreamHandler(sys.stdout, MyFormatter())
    sh.setLevel(getattr(Level, level))
    logger.addHandler(sh)
    return logger
