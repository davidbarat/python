import sys

################
# FUNCTIONS
################

def get_servers(nodename):
   node = AdminConfig.getid("/Node:" + nodename)
   serverlist = AdminConfig.list('Server', node).split("\n")
   # La liste pouvant contenir des webservers et autres, on ne garde que les sa et le nodeagent
   nb_sa=0
   for server in serverlist[:]:
      servertype = AdminConfig.showAttribute(server, 'serverType')
      if servertype != 'APPLICATION_SERVER' and servertype != 'NODE_AGENT':
         serverlist.remove(server)
      else:
	 nb_sa += 1
   return serverlist,(nb_sa - 1)

def get_dmgrserver(nodename): # On identifie le serveur/noeud hebergeant le DMGR
   cell = AdminConfig.list('Cell')
   cellname = AdminConfig.showAttribute(cell, 'name')
   dmgrhostname = cellname.replace('Network', '')
   if dmgrhostname == nodename:
      dmgr = AdminConfig.list('CellManager')
      dmgrserver = AdminConfig.list('Server', dmgr)
   else:
      dmgrserver = 'nodmgr'
   return dmgrserver

def get_heapsize(server):
   servername = AdminConfig.showAttribute(server, 'name')
   servertype = AdminConfig.showAttribute(server, 'serverType')
   jvm = AdminConfig.list('JavaVirtualMachine', server)
   minheapsize = AdminConfig.showAttribute(jvm, 'initialHeapSize')
   maxheapsize = AdminConfig.showAttribute(jvm, 'maximumHeapSize')
   if servertype == 'NODE_AGENT' or servertype == 'DEPLOYMENT_MANAGER':
      if minheapsize == '0':
         minheapsize = '50'
      if maxheapsize == '0':
         maxheapsize = '256'
   line = servername + "," + minheapsize + "," + maxheapsize + "\n"
   return line
   
########
# MAIN
########

# Le nom du noeud correspond au hostname
nodename = sys.argv[0]
cvs_file = sys.argv[1]

serverlist,nb_sa = get_servers(nodename) # Liste des SA 
print("Qty of SA on node %s : %s" % (nodename,nb_sa))

dmgrserver = get_dmgrserver(nodename)
if dmgrserver != 'nodmgr':
   serverlist.append(dmgrserver)
   
jvmlist = ""
for server in serverlist: 
   jvmlist = jvmlist + get_heapsize(server)

jvmlistfile = open(cvs_file, 'a')
jvmlistfile.write(jvmlist)
jvmlistfile.write("SA_QTY:%s" % nb_sa)
jvmlistfile.close()
