# -------------------
# Import des modules
# -------------------

# execfile('wsadminlib.py')

_modules = [
    'sys',
    'time',
    're',
    'glob',
    'os',
    'getopt',
    'traceback',
    'java',
    'javax.management',
    ]

for module in _modules:
    if module == "javax.management":
        import javax.management as mgmt
    else:
        try:
            locals()[module] = __import__(module, {}, {}, [])
        except ImportError:
            print("[WARNING : functions] Error importing '%s'." % module)

sys.path.append(os.environ["ROOT_DIR"] + "/python")
from customlog import define_logger

# Logging configuration
log = define_logger("functions", "INFO")

# --------------------
# Variables globales
# --------------------

# -----------------------
# Methodes de wsadminlib
# -----------------------
try:
    AdminConfig = sys._getframe(1).f_locals['AdminConfig']
    AdminApp = sys._getframe(1).f_locals['AdminApp']
    AdminControl = sys._getframe(1).f_locals['AdminControl']
    AdminTask = sys._getframe(1).f_locals['AdminTask']
    AdminResources  = sys._getframe(1).f_locals['AdminResources']
    AdminJDBC = sys._getframe(1).f_locals['AdminJDBC']
    AdminServerManagement = sys._getframe(1).f_locals['AdminServerManagement']
except:
    log.warning("Caught exception accessing Admin objects. Continuing.")


def _splitlist(s):
    """
    Conversion chaine de caracteres en crochets en une liste
    (separateur : espace)
    """
    if s[0] != '[' or s[-1] != ']':
        raise "Invalid string: %s" % s
    return s[1:-1].split(' ')


def _splitlines(s):
    """Decoupage de lignes en une liste"""
    rv = [s]
    if '\r' in s:
        rv = s.split('\r\n')
    elif '\n' in s:
        rv = s.split('\n')
    if rv[-1] == '':
        rv = rv[:-1]
    return rv


def _noendcar(s):
    """Suppression caractere de fin de ligne"""
    if '\n' in s:
        rv = s.replace('\n', "")
    else:
        rv = s
    return rv


def listToString(s):
    """
    Conversion d une liste en une chaine de caracteres
    (separateur : espace)
    """
    s = "".join(s)
    return s


def checkFic(fic):
    """Verification de l existence et de l acces � un fichier"""
    try:
        obFic = open(fic, "r")
        obFic.close()
        return 1
    except:
        log.severe("Probleme lors de l ouverture du fichier %s" % fic)
        sys.exit(10)


def getObjectAttribute(objectid, attributename):
    """Valeur de l attribut d un objet"""
    log.finest("BEGIN getObjectAttribute(objectid, attributename)")
    log.finest("  objectid = %s" % objectid)
    log.finest("  attributename = %s" % attributename)
    attributename = "\'" + attributename + "\'"
    result = AdminConfig.showAttribute(objectid, attributename)
    if result is not None and result.startswith("[") and result.endswith("]"):
        result = _splitlist(result)
    log.finest("END getObjectAttribute - Returns : %s" % result)
    return result


def getObjectsOfType(typename, scope=None):
    """Liste des ID d objets definis dans une portee (fournie ou non)"""
    log.finest("BEGIN getObjectsOfType(typename, scope=None)")
    log.finest("  typename = %s" % typename)
    log.finest("  scope = %s" % scope)
    m = "getObjectsOfType:"
    if scope:
        result = AdminConfig.list(typename, scope).splitlines()
        log.finest("END getObjectsOfType - Returns : %s" % result)
        return result
    else:
        result = AdminConfig.list(typename).splitlines()
        log.finest("END getObjectsOfType - Returns : %s" % result)
        return result


def getCfgItemId(scope, nodeName, serverName, objectType="", item="/"):
    """
    Retourne l'ID d un objet
    Si item non fourni, par d�faut, affichage de tous les objets
    """
    if (scope == "cell"):
        cellName = getCellName()
        cfgItemId = AdminConfig.getid(
            "/Cell:" + cellName
            + "/" + objectType + ":" + item
            )
    elif (scope == "node"):
        cfgItemId = AdminConfig.getid(
            "/Node:" + nodeName
            + "/" + objectType + ":" + item
            )
    elif (scope == "server"):
        cfgItemId = AdminConfig.getid(
            "/Node:" + nodeName
            + "/Server:" + serverName
            + "/" + objectType + ":" + item
            )
    elif (scope == "None"):
        cfgItemId = AdminConfig.getid(
            "/Node:" + nodeName
            + "/Server:" + serverName + "/"
            )
    return cfgItemId


def getCellName():
    """Retourne le nom de la cellule"""
    cellname = AdminControl.getCell()
    return cellname


def getCellId(cellname=None):
    """Retourne l'ID de la cellule"""
    if cellname is None:
        cellname = getCellName()
    return AdminConfig.getid('/Cell:%s/' % cellname)


def getNodeId(nodename):
    """Retourne l'ID d'un noeud"""
    return AdminConfig.getid('/Cell:%s/Node:%s/' % (getCellName(), nodename))


def getObjectByNodeAndName(nodename, typename, objectname):
    """
    Recuperation d'objets cibles
    Exemple : getObjectByNodeAndName('parva2406515','Node','ApplicationServer')
    """
    node_id = getNodeId(nodename)
    all = _splitlines(AdminConfig.list(typename, node_id))
    result = None
    for obj in all:
        name = AdminConfig.showAttribute(obj, 'name')
        if name == objectname:
            if result is not None:
                raise (
                    "FOUND more than one %s with name %s"
                    % (typename, objectname)
                    )
            result = obj
    return result


def getServerId(nodename, servername):
    """ID d un serveur d applications"""
    id = getObjectByNodeAndName(nodename, "Server", servername)  # App server
    if id is None:
        id = getObjectByNodeAndName(nodename, "ProxyServer", servername)
    return id


def listAppOfSA(cellName, nodeName, serverName):
    """Liste des applications que renferme un SA donne"""
    apps = _splitlines(
        AdminApp.list(
            "Websphere:cell=" + cellName
            + ",node=" + nodeName
            + ",server=" + serverName
            )
        )
    return apps


def getListJndiByAppli(appName):
    """Ressources JNDI a partir d'un nom d'appli"""
    appMgmt = mgmt.ObjectName(
        AdminControl.completeObjectName("WebSphere:*,type=AppManagement")
        )
    appInfo = AdminControl.invoke_jmx(
        appMgmt,
        "getApplicationInfo",
        [appName, java.util.Hashtable(), None],
        ["java.lang.String", "java.util.Hashtable", "java.lang.String"]
        )
    return appInfo


def getUrlByDs(ds):
    """Recuperation url a partir datasource"""
    DS_customProp = AdminConfig.showAttribute(ds, 'propertySet')
    log.finer("DS_customProp = %s" % DS_customProp)
    DS_ressourceProp = AdminConfig.showAttribute(DS_customProp,
                                                 'resourceProperties')
    log.finer("DS_ressourceProp = %s" % DS_ressourceProp)
    rpsarray = DS_ressourceProp[1:len(DS_ressourceProp)-1].split(' ')
    for rp in rpsarray:
        name = AdminConfig.showAttribute(rp, 'name')
        if name == 'URL':
            urlDs = AdminConfig.showAttribute(rp, 'value')
            return urlDs


def JndiNameRelation_ds_url(application, findAuth="Auth"):
    """Ressources JNDI pour les ressources JDBC"""
    listAppinfo = getListJndiByAppli(application)
    for task in listAppinfo:
        if task.getName() == "MapResRefToEJB":
            dico = {}
            resRefs = task.getTaskData()

            if resRefs is not None:
                champResAppli = 5
                champResWeb = 8
                for i in range(1, len(resRefs)):
                    cle = resRefs[i][champResWeb]
                    valeur = resRefs[i][champResAppli]
                    dico[cle] = valeur
    return dico


def JndiNameRelation_env(application, findAuth="Auth"):
    """Ressources JNDI pour les ressources ENV"""
    listAppinfo = getListJndiByAppli(application)
    for task in listAppinfo:
        if task.getName() == "MapResEnvRefToRes":
            dico = {}
            resRefs = task.getTaskData()

            if resRefs is not None:
                champResAppli = 3
                champResWeb = 5
                for i in range(1, len(resRefs)):
                    cle = resRefs[i][champResWeb]
                    valeur = resRefs[i][champResAppli]
                    dico[cle] = valeur
    return dico


def retrieveJNDI(application, jndiName, findAuth="Auth"):
    """
    Recherche de la ressource JNDI Web fournie dans le fichier .props
    Fait elle partie des ressources actuelles dans l'application ?
    Pour les ressources URL et DS
    """
    listAppinfo = getListJndiByAppli(application)
    for task in listAppinfo:
        if task.getName() == "MapResRefToEJB":
            resRefs = task.getTaskData()
            dico = {}
            champResAppli = 5
            champResWeb = 8
            for i in range(1, len(resRefs)):
                dico[resRefs[i][champResAppli]] = resRefs[i][champResWeb]
    try:
        if dico[jndiName] is not None:
            return dico[jndiName]
    except:
        dico = None
        return dico


def retrieveJNDI_env(application, jndiName, findAuth="Auth"):
    """
    Recherche de la ressource JNDI Web fourni dans le fichier .props
    Fait elle partie des ressources actuelles dans l'application ?
    Pour les ressources ENV
    """
    listAppinfo = getListJndiByAppli(application)
    for task in listAppinfo:
        if task.getName() == "MapResEnvRefToRes":
            resRefs = task.getTaskData()
            if resRefs is not None:
                dico = {}
                champResAppli = 3
                champResWeb = 5
                for i in range(1, len(resRefs)):
                    dico[resRefs[i][champResAppli]] = resRefs[i][champResWeb]
    try:
        if dico[jndiName] is not None:
            return dico[jndiName]
    except:
        dico = None
        return dico


def configureFederation(appName):
    """ID du container de deploiement"""
    appDeploymentContainment = (
        "/Deployment:%s/ApplicationDeployment:/"
        ) % appName
    appDeployment = AdminConfig.getid(appDeploymentContainment)
    return appDeployment


def getLibrairies():
    """
    Chemin des log4j, des shared libs et des shared classes pour un SA donne
    """
    libraryId = getCfgItemId("server", nodeName, serverName, "Library")
    log.info("- Chemin des log4j,des shared libs et des shared classes :")
    if libraryId:
        librairies = (
            AdminConfig.showAttribute(libraryId, 'classPath').split(";")
            )
        for i in librairies:
            log.info("%s" % i)
    else:
        log.info("Non defini")


def extractConfigProperties(nodename, servername, propsfilename):
    """Conversion du fichier de configuration xml d'un SA en un fichier plat"""
    m = "extractConfigProperties:"
    arglist = [
        '-propertiesFileName',
        propsfilename,
        '-configData',
        'Server=%s' % servername
        ]
    sop(m,
        ("Calling AdminTask.extractConfigProperties() "
         "with arglist=%s") % arglist
        )
    return AdminTask.extractConfigProperties(arglist)


def getAdminAppViewValue(appname, keyname, parsename):
    """
    Methode permettant de formater l affichage de certaines valeurs
    appelees avec certaines methodes AdminApp.view par exemple
    """
    m = "getAdminAppViewValue:"
    sop(m,
        "Entry. appname=%s keyname=%s parsename=%s" % (appname, keyname,
                                                       parsename)
        )
    verboseString = AdminApp.view(appname, [keyname])
    sop(m, "verboseString=%s" % verboseString)
    verboseStringList = _splitlines(verboseString)
    for str in verboseStringList:
        if str.startswith(parsename):
            resultString = str[len(parsename):].strip()
            sop(m, "Exit. Found value. Returning >>>%s<<<" % resultString)
            return resultString
    sop(m, "Exit. Did not find value. Returning None.")
    return None


def getApplicationVirtualHost(appname):
    """Caracteristiques d un Virtual Host"""
    return getAdminAppViewValue(appname, "-MapWebModToVH", "Virtual host:")


def changeURLDatasource(ds, url):
    """Modification d une ressource JDBC"""
    DS_customProp = AdminConfig.showAttribute(ds, 'propertySet')
    # ressource properties
    DS_ressourceProp = AdminConfig.showAttribute(DS_customProp,
                                                 'resourceProperties')
    # recherche de la valeur de url datasource
    rpsarray = DS_ressourceProp[1:len(DS_ressourceProp)-1].split(' ')
    for rp in rpsarray:
            name = AdminConfig.showAttribute(rp, 'name')
            if name == 'URL':
                urlDs = AdminConfig.showAttribute(rp, 'value')
                log.info(
                    "Mise � jour de la datasource avec la valeur suivante : %s"
                    % url
                    )
                AdminConfig.modify(rp, [["name", "URL"], ["value", url]])


def changeREEpropriety(idRess, jndiAppli, nomRess, allProperties, node, sa):
    """Modification d une ressource ENV"""
    PropertyCouple = {}
    PropertyNames = []
    for cle, valeur in allProperties.items():
        nomProperty = PropertyNames.append(valeur[0])
        PropertyCouple[valeur[0]] = valeur[1]
    # print("PropertyNames : %s" % PropertyNames)

    nbProps = len(allProperties)

    idSA = getServerId(node, sa)
    cellname = getCellName()
    ressProviderIds = getObjectsOfType('ResourceEnvironmentProvider',
                                       '%s' % idSA)

    currentProperties = []
    for ressProviderId in ressProviderIds:
        reeProviderName = getObjectAttribute(ressProviderId, 'name')
        reeEntryIds = _splitlines(
            AdminConfig.getid(
                '/Cell:' + cellname
                + '/Node:' + node
                + '/Server:' + sa
                + '/ResourceEnvironmentProvider:' + reeProviderName
                + '/ResourceEnvEntry:/'
                )
            )

        for reeEntry in reeEntryIds:
            if reeEntry == idRess:
                reeName = getObjectAttribute(reeEntry, 'name')
                reeJndiNameWeb = getObjectAttribute(reeEntry, 'jndiName')
                reepropertySetId = getObjectAttribute(reeEntry, 'propertySet')
                J2EEResourcePropertyIds = _splitlines(
                    AdminConfig.list('J2EEResourceProperty', reepropertySetId)
                    )
                # print("J2EEResourcePropertyIds : %s" % J2EEResourcePropertyIds)

                for J2EEResourceProperty in J2EEResourcePropertyIds:
                    J2EEResourcePropertyName = getObjectAttribute(
                        J2EEResourceProperty, 'name'
                        )
                    # print("J2EEResourcePropertyName : %s" % J2EEResourcePropertyName)
                    J2EEResourcePropertyValue = getObjectAttribute(
                        J2EEResourceProperty, 'value'
                        )
                    currentProperties.append(J2EEResourcePropertyName)
                    if J2EEResourcePropertyName in PropertyNames:
                        # Existence de la propriete
                        # La propriete existe deja,
                        # il s agit donc d une simple modification
                        log.info(
                            "Modification, pour la ressource env (%s), "
                            "de la propriete : %s, nouvelle valeur : %s"
                            % (jndiAppli, J2EEResourcePropertyName,
                               PropertyCouple[J2EEResourcePropertyName])
                            )
                        AdminConfig.modify(
                            J2EEResourceProperty,
                            [
                                ['name', J2EEResourcePropertyName],
                                ['value',
                                 PropertyCouple[J2EEResourcePropertyName]]
                            ]
                            )
                    else:
                        # La propriete n existe pas, il s agit de la supprimer
                        # pour etre conforme avec la FMOE
                        # puis re creation de la propriete
                        log.info(
                            "Suppression, pour la ressource env (%s), "
                            "de la propriete (%s), dont la valeur est : %s"
                            % (jndiAppli, J2EEResourcePropertyName,
                               J2EEResourcePropertyValue)
                            )
                        AdminConfig.remove(J2EEResourceProperty)
    # print("currentProperties : %s" % currentProperties)
    for newProperty in PropertyNames:
        if newProperty not in currentProperties:
            log.info(
                "Creation, pour la ressource env (%s), "
                "d une nouvelle propriete (%s), dont la valeur est : %s"
                % (jndiAppli, newProperty, PropertyCouple[newProperty])
                )
            AdminConfig.create(
                'J2EEResourceProperty',
                reepropertySetId,
                [['name', newProperty], ['value', PropertyCouple[newProperty]]]
                )


def isServerRunning(nodename, servername):
    """
    Status d un serveur d applications
    True : SA demarre, False : SA stoppe
    """
    mbean = AdminControl.queryNames(
        'type=Server,node=%s,name=%s,*' % (nodename, servername)
        )
    return mbean


def SyncNode(nodename):
    """Synchronisation d un noeud"""
    Sync1 = AdminControl.completeObjectName(
        'type=NodeSync,node=' + nodename + ',*'
        )
    return AdminControl.invoke(Sync1, 'sync')


def startWebServer(nodename, servername):
    """Demarrage d un web server"""
    m = "startWebServer: "
    sop(m, "Entry.")
    sop(m,
        "Got arguments: nodename=%s, servername=%s" % (nodename, servername))
    mbean = AdminControl.queryNames('WebSphere:type=WebServer,*')
    sop(m, mbean)
    cell = AdminControl.getCell()
    sop(m, cell)
    webServerUp = AdminControl.invoke(
        mbean,
        'start',
        '[%s %s %s]' % (cell, nodename, servername),
        '[java.lang.String java.lang.String java.lang.String]'
        )
    sop(m, webServerUp)


def stopWebServer(nodename, servername):
    """Arret d un web server"""
    m = "stopWebServer: "
    sop(m, "Entry.")
    sop(m,
        "Got arguments: nodename=%s, servername=%s" % (nodename, servername))
    mbean = AdminControl.queryNames('WebSphere:type=WebServer,*')
    sop(m, mbean)
    cell = AdminControl.getCell()
    sop(m, cell)
    webServerDown = AdminControl.invoke(
        mbean,
        'stop',
        '[%s %s %s]' % (cell, nodename, servername),
        '[java.lang.String java.lang.String java.lang.String]'
        )
    sop(m, webServerDown)


# Global variable defines extra time to wait for a server to start, in seconds.
waitForServerStartSecs = 300


def setWaitForServerStartSecs(val):
    """Sets global variable used to wait for servers to start, in seconds."""
    global waitForServerStartSecs
    waitForServerStartSecs = val


def getWaitForServerStartSecs():
    """
    Returns the global variable used to wait for servers to start, in seconds.
    """
    global waitForServerStartSecs
    return waitForServerStartSecs


def stopServer(nodename, servername):
    """Arret d un serveur d applications"""
    log.info("------------------------")
    log.info("STOP SERVER APPLICATION ")
    log.info("------------------------")

    if isServerRunning(nodename, servername):
        serverStatus = AdminControl.queryNames(
            'WebSphere:*,type=Server,node=%s,process=%s'
            % (nodename, servername)
            )
        AdminControl.invoke(
            AdminControl.queryNames(
                'WebSphere:*,type=Server,node=%s,process=%s'
                % (nodename, servername)
                ),
            'stop'
            )

        while isServerRunning(nodename, servername):
            log.info("Serveur toujours present ....")
            time.sleep(10)
        log.info("Serveur arrete")
    else:
        log.info("Le serveur semble deja arrete.")


def startServer(nodename, servername):
    """Demarrage d un serveur d applications"""
    m = "startServer:"
    if isServerRunning(nodename, servername):
        sop(m, "Le serveur %s,%s est deja demarre" % (nodename, servername))
    else:
        log.info("-------------------------")
        log.info("START SERVER APPLICATION")
        log.info("-------------------------")
        sop(m, "Demarrage du serveur %s,%s" % (nodename, servername))
        try:
            sop(m, "startServer(%s,%s)" % (servername, nodename))
            AdminControl.startServer(servername, nodename, 240)

            global waitForServerStartSecs
            waitRetries = waitForServerStartSecs / 15
            if waitRetries < 1:
                waitRetries = 1
            retries = 0
            while (not isServerRunning(nodename, servername)
                   and retries < waitRetries):
                sop(m,
                    ("Le serveur %s,%s est toujours en cours de demarrage, "
                     "merci de patienter encore 15 secs")
                    % (nodename, servername)
                    )
                time.sleep(15)  # seconds
                retries += 1
            if not isServerRunning(nodename, servername):
                sop(m,
                    "server %s,%s STILL not running, giving up" % (nodename,
                                                                   servername))
                raise Exception(
                    "SERVER FAILED TO START %s,%s" % (nodename, servername)
                    )
            else:
                log.info("Le serveur est � present demarre.")

        except:
            (exception, parms, tback) = sys.exc_info()
            if -1 != repr(parms).find("already running"):
                return
            sop(m, "EXCEPTION STARTING SERVER %s" % servername)
            sop(m, "Exception=%s\nPARMS=%s" % (str(exception), repr(parms)))
            raise Exception(
                "EXCEPTION STARTING SERVER %s: %s %s"
                % (servername, str(exception), str(parms))
                )


# ----------------
# Divers methodes
# ----------------


def getSopTimestamp():
    formatting_string = (
        "[" + "%" + "Y-" + "%" + "m" + "%" + "d-"
        + "%" + "H" + "%" + "M-" + "%" + "S00]"
        )
    return time.strftime(formatting_string)


DEBUG_SOP = 0


def enableDebugMessages():
    global DEBUG_SOP
    DEBUG_SOP = 1
    sop(
        'enableDebugMessages',
        "Verbose trace messages are now enabled; "
        + "future debug messages will now be printed."
        )


def disableDebugMessages():
    global DEBUG_SOP
    sop(
        'enableDebugMessages',
        "Verbose trace messages are now disabled; "
        + "future debug messages will not be printed."
        )
    DEBUG_SOP = 0


# -------------------------
# Formatage de l affichage
# -------------------------


def sop(methodname, message):
    global DEBUG_SOP
    if DEBUG_SOP:
        timestamp = getSopTimestamp()
        log.info("%s %s %s" % (timestamp, methodname, message))


def emptyString(strng):
    if strng is None or strng == "":
        return True
    return False


def CreateNewSA(node, sa):
    """Creation d un SA generique"""
    rechSA = AdminConfig.list('Server', "*%s*" % sa)
    if rechSA is None or rechSA == "":
        idNewSA = AdminServerManagement.createApplicationServer(node,
                                                                sa, "default")
        AdminConfig.save()
        log.info("Server %s created" % sa)
        return idNewSA
    else:
        log.info("Server %s already exists" % sa)
        return rechSA


def checkIfSAexists(sa):
    """Verification existence SA et application"""
    cellule = getCellId()
    cellName = getCellName()
    nodes = getObjectsOfType('Node', cellule)

    SAid = None
    nodeName = None
    appliName = None

    recherche = 'non trouve'
    appServers = getObjectsOfType('Server')
    for server in appServers:
        servers = getObjectAttribute(server, "name")
        if sa == servers:
            SAid = server
            posStringNode = SAid.find("nodes")
            posFin = SAid.find("/", posStringNode + 6)
            nodeName = SAid[posStringNode+6:posFin]
            # posNodeName = posStringNode + 6
            # nodeName = SAid[posNodeName:(posNodeName + 12)]
            recherche = 'trouve'

    if (recherche == "trouve"):
        apps = listAppOfSA(cellName, nodeName, sa)
        nbApps = int(len(apps))

        if (nbApps > 0):
            for appli in apps:
                if appli != "ibmasyncrsp":
                    idJVM = AdminConfig.list('JavaVirtualMachine', SAid)
                    appliName = appli
    return SAid, nodeName, appliName


def get_ds_list(scope, application=None):
    """Liste des ressources JDBC pour un SA donne"""
    idDatasources = getObjectsOfType('DataSource', scope)

    if len(idDatasources) > 0:
        dico = JndiNameRelation_ds_url(application)
        if dico is not None:
            compteur = 1
            for datasource in idDatasources:
                dsName = getObjectAttribute(datasource, 'name')
                if (dsName != "DefaultEJBTimerDataSource"
                        and dsName != "Oracle JDBC Driver XA DataSource"):
                    dsJndiNameWeb = getObjectAttribute(datasource, 'jndiName')
                    for k in dico.keys():
                        if k == dsJndiNameWeb:
                            dsJndiNameApp = dico[dsJndiNameWeb]
                            url = getUrlByDs(datasource)

                            # print "ds%s" % str(compteur) + ".JDBC_TYPE_ACTION=update"
                            print("ds%s" % str(compteur)
                                     + ".JDBC_JNDI_WEB=%s" % dsJndiNameWeb)
                            print("ds%s" % str(compteur)
                                     + ".JDBC_JNDI_APPLI=%s" % dsJndiNameApp)

                            auth = get_auth_data(datasource)
                            alias = getObjectAttribute(auth, 'alias')
                            login = getObjectAttribute(auth, 'userId')
                            pwd = getObjectAttribute(auth, 'password')
                            # print "ds%s" % str(compteur)+".JDBC_ALIAS=%s" % alias
                            print("ds%s" % str(compteur)
                                     + ".JDBC_ALIAS_USER=%s" % login)
                            print("ds%s" % str(compteur)
                                     + ".JDBC_ALIAS_PASS=%s" % pwd)
                            print("ds%s" % str(compteur)
                                     + ".JDBC_URL=%s" % url)
                            print("\n")
                            compteur = compteur + 1


def get_url_list(scope, application=None):
    """Liste des ressources URL pour un SA donne"""
    urlsId = getObjectsOfType('URL', scope)

    if len(urlsId) > 0:
        dico = JndiNameRelation_ds_url(application)
        compteur = 1
        for url in urlsId:
            # print "URL resource n�%s" % compteur, ":"
            urlName = getObjectAttribute(url, 'name')
            urlJndiNameWeb = getObjectAttribute(url, 'jndiName')
            for k in dico.keys():
                if k == urlJndiNameWeb:
                    urlJndiNameApp = dico[urlJndiNameWeb]
                    urlSpec = getObjectAttribute(url, 'spec')

                    # print "url%s" % str(compteur)+".URL_TYPE_ACTION=update"
                    print ("url%s" % str(compteur)
                           + ".URL_JNDI_WEB=%s" % urlJndiNameWeb)
                    print ("url%s" % str(compteur)
                           + ".URL_JNDI_APPLI=%s" % urlJndiNameApp)
                    print "url%s" % str(compteur) + ".URL_SPEC=%s" % urlSpec
                    print "\n"
                    compteur = compteur + 1


def get_ree_list(scope, application=None):
    """Liste des ressources ENV pour un SA donne"""
    ressProviderIds = getObjectsOfType('ResourceEnvironmentProvider', scope)
    nbressProviders = int(len(ressProviderIds))

    if len(ressProviderIds) > 0 and application is not None:
        dico = JndiNameRelation_env(application)
        # reeRefIds = {}
        reeEntryIds = {}

        for provider in ressProviderIds:
            compteur_entree = 1
            reeProviderName = getObjectAttribute(provider, 'name')
            # print "Provider : %s" % reeProviderName

            # reeRefIds = _splitlines(AdminConfig.getid('/Cell:' + cellName + '/Node:' + nodeName + '/Server:' +  serverName + '/ResourceEnvironmentProvider:' + reeProviderName + '/Referenceable:/'))
            reeEntryIds = _splitlines(
                AdminConfig.getid(
                    '/Server:' + getObjectAttribute(scope, 'name')
                    + '/ResourceEnvironmentProvider:' + reeProviderName
                    + '/ResourceEnvEntry:/'
                    )
                )

            # listReferenceables = {}
            # for referenceable in reeRefIds:
            #     nomFabrique = getObjectAttribute(referenceable, 'factoryClassname')
            #     nomClasse = getObjectAttribute(referenceable, 'classname')
            #     listReferenceables[nomFabrique] = nomClasse

            # for fabrique, classe in listReferenceables.items():
            #     print("\t\t%s, %s" % (fabrique, classe))

            for reeEntry in reeEntryIds:
                # print "ree%s" % str(compteur_entree)+".REE_TYPE_ACTION=update"
                entryName = getObjectAttribute(reeEntry, 'name')
                entryJndiWeb = getObjectAttribute(reeEntry, 'jndiName')
                if dico != {}:
                    for k in dico.keys():
                        if k == entryJndiWeb:
                            reeJndiNameApp = dico[entryJndiWeb]
                            print("ree%s" % str(compteur_entree)
                                  + ".REE_ENTRY_JNDI_WEB=%s" % entryJndiWeb)
                            print(
                                "ree%s" % str(compteur_entree)
                                + ".REE_ENTRY_JNDI_APPLI=%s" % reeJndiNameApp
                                )

                            referenceableId = getObjectAttribute(
                                reeEntry, 'referenceable')
                            referenceableName = getObjectAttribute(
                                referenceableId, 'factoryClassname')
                            print("ree%s" % str(compteur_entree)
                            	  + ".REE_FACTORY_NAME=%s" % referenceableName)

                            referenceableClass = getObjectAttribute(
                                referenceableId, 'classname')
                            print("ree%s" % str(compteur_entree)
                                  + ".REE_CLASS_NAME=%s" % referenceableClass)

                            reepropertySetIds = getObjectAttribute(
                                reeEntry, 'propertySet')
                            J2EEResourcePropertyIds = _splitlines(
                                AdminConfig.list('J2EEResourceProperty',
                                                 reepropertySetIds)
                                )
                            listProperties = {}
                            compteur_propriete = 1
                            for property in J2EEResourcePropertyIds:
                                J2EEResourcePropertyName = getObjectAttribute(
                                    property, 'name')
                                print(
                                    "ree%s" % str(compteur_entree)
                                    + ".REE_ENTRY_PROP_NAME%s" % str(
                                            compteur_propriete)
                                    + "=%s" % J2EEResourcePropertyName
                                    )

                                J2EEResourcePropertyValue = getObjectAttribute(
                                    property, 'value')
                                print(
                                    "ree%s" % str(compteur_entree)
                                    + ".REE_ENTRY_PROP_VALUE%s" % str(
                                        compteur_propriete)
                                    + "=%s" % J2EEResourcePropertyValue
                                    )

                                listProperties[J2EEResourcePropertyName] = \
                                    J2EEResourcePropertyValue
                                compteur_propriete = compteur_propriete + 1
                    print ""
                compteur_entree = compteur_entree + 1


def updateUrlAction(idRess, nomRess, t_Ress):
    """Update URL"""
    for key, value in t_Ress.items():
        if nomRess == key:
            log.info("Nouvelle valeur : %s" % t_Ress[key]['URL_SPEC'])
            AdminConfig.modify(idRess, [['spec', t_Ress[key]['URL_SPEC']]])


def updateDsAction(idRess, nomRess, t_Ress):
    """Update DataSource"""
    global flagErreur
    for key, value in t_Ress.items():
        if nomRess == key:
            if t_Ress[nomRess]['JDBC_URL'] != "":
                changeURLDatasource(idRess, t_Ress[nomRess]['JDBC_URL'])
                flagErreur = 0
                log.info("JDBC_ALIAS_PASS : %s"
                         % t_Ress[nomRess]['JDBC_ALIAS_PASS'])
                auth = get_auth_data(idRess)
                set_auth_data(auth,
                            t_Ress[nomRess]['JDBC_ALIAS_USER'],
                            t_Ress[nomRess]['JDBC_ALIAS_PASS']
                            )
            else:
                log.severe("ERREUR(8) : La valeur de l instance "
                           "de la ressource DS n a pas ete specifiee\n")
                flagErreur = 1


def updateReeAction(idRess, jndiAppli, nomRess,
                    allProperties, node, sa):
    """Update Ree"""
    changeREEpropriety(idRess, jndiAppli, nomRess,
                       allProperties, node, sa)


def createUrl(node, sa, urlJndi, nomRess, t_Ress, appli):
    """Creation ressource URL"""
    global flagErreur
    URLProviderName = "Default URL Provider"
    URLStreamHandlerClass = "unused"
    URLProtocol = "unused"
    URLName = re.sub(r"^.*/", r"", urlJndi)
    ressName = appli + "_" + URLName + "_url"
    URLJndiWeb = "url/" + appli + "_" + URLName

    try:
        idRessUrlcreated = AdminResources.createURL(
            node, sa, URLProviderName, ressName,
            URLJndiWeb, t_Ress[nomRess]['URL_SPEC']
            )
        log.info("Ressource URL creee (ID = %s)" % idRessUrlcreated)
        flagErreur = 0

    except:
        if t_Ress[nomRess]['URL_SPEC'] == "":
            log.severe("ERREUR(8) : La valeur de la ressource URL "
                       "n a pas ete specifiee\n")
            flagErreur = 1

        elif getCfgItemId(
                "server", node, sa,
                "URLProvider:/URL", "%s" % ressName) is not None:
            log.warning("Cette ressource URL existe deja. "
                        "Elle a ete mise a jour.")
            log.info(
                "Nom JNDI : %s"
                % AdminConfig.showAttribute(
                    getCfgItemId(
                        "server", node, sa, "URLProvider:/URL",
                        "%s" % ressName
                        ),
                    'jndiName'
                    )
                )
            log.info(
                "Ancienne valeur : %s"
                % AdminConfig.showAttribute(
                    getCfgItemId(
                        "server", node, sa,
                        "URLProvider:/URL", "%s" % ressName
                        ),
                    'spec'
                    )
                )
            idRess = getCfgItemId(
                "server", node, sa, "URLProvider:/URL", "%s" % ressName)
            updateUrlAction(idRess, nomRess, t_Ress)

        else:
            log.severe("ERREUR(10) : la ressource URL n a pas pu etre creee. "
                       "No Save")
            flagErreur = 1


def createDs(node, sa, jdbcJndi, nomRess, t_Ress, appli, shared_jdbc_dir):
    """Creation ressource JDBC"""
    log.fine("BEGIN createDs(node, sa, jdbcJndi, nomRess,"
             " t_Ress, appli, shared_jdbc_dir)")
    log.fine("  node = %s" % node)
    log.fine("  sa = %s" % sa)
    log.fine("  jdbcJndi = %s" % jdbcJndi)
    log.fine("  nomRess = %s" % nomRess)
    log.fine("  t_Ress = %s" % t_Ress)
    log.fine("  appli = %s" % appli)
    log.fine("  shared_jdbc_dir = %s" % shared_jdbc_dir)

    global flagErreur
    userOracle = t_Ress[nomRess]['JDBC_ALIAS_USER']
    passOracle = t_Ress[nomRess]['JDBC_ALIAS_PASS']
    urlOracle = t_Ress[nomRess]['JDBC_URL']
    try:
        dsProps = eval(t_Ress[nomRess]['JDBC_PROPERTIES'])
    except:
        dsProps = []
    try:
        poolProps = eval(t_Ress[nomRess]['JDBC_POOL_PROPERTIES'])
    except:
        poolProps = []

    # formatage du nom de la ressource jdbc
    jdbcRessName = appli + "_ds_" + re.sub(r"^.*/", r"", jdbcJndi)

    # formatage du nom de l alias
    jdbcAliasAuth = appli + "_alias_" + re.sub(r"^.*/", r"", jdbcJndi)

    # formatage nom JNDI JDBC sous Websphere
    jndiWebName = "jdbc/" + appli + "_" + re.sub(r"^.*/", r"", jdbcJndi)

    # initialisation des drivers oracle et des classpath
    prm_classpath = ""

    versionOracle = t_Ress[nomRess]['JDBC_VERSION']
    if(versionOracle == ""
       or versionOracle == "10" or versionOracle == "10.0"
       or versionOracle == "11" or versionOracle == "11.0"
       ):
        driversOracle = "ojdbc6.jar"
    elif versionOracle == "12" or versionOracle == "12.0":
        driversOracle = "ojdbc7.jar"
    else:
        driversOracle = "ojdbc6.jar"

    if os.environ["ARA_FLAG"] == "true":
        try:
            tryDrivers = t_Ress[nomRess]['JDBC_DRIVERS']
            if tryDrivers != "":
                driversOracle = tryDrivers
        except:
            log.severe("JDBC_DRIVERS n'existe pas dans le fichier .props !")

    drivers = driversOracle.split(";")
    d = []
    for driver in drivers:
        driver = "%s/%s" % (shared_jdbc_dir, driver)
        d.append(driver)
    driver_classpath = ";".join(d)
    prm_classpath = "%s" % driver_classpath

    # initialisation variables testant l existence ou non
    # d un provider, d un alias, ou d une datasource
    existence_provider = 0
    existence_alias = 0

    # Verification de l existence du provider pour l application mentionnee
    jdbcProviderName = "driver_" + jdbcRessName
    jdbcProviderType = "Oracle JDBC Driver"
    listProviders = _splitlines(
        getCfgItemId("server", node, sa, "JDBCProvider:")
        )

    if listProviders != "None" and listProviders != "":
        log.info("Providers actuels :")
        for provider in listProviders:
            name_provider = AdminConfig.showAttribute(provider, 'name')
            type = AdminConfig.showAttribute(provider, 'providerType')
            log.info("%s" % name_provider)
            if(name_provider == jdbcProviderName
               and (type == jdbcProviderType or type is None)):
                log.info("Le provider \"%s\" existe deja." % jdbcProviderName)
                existence_provider = 1

    if existence_provider == 0:
        log.info("Aucun provider n est reference pour cette datasource.")
        # creation du provider jdbc
        description = "Oracle JDBC Driver"  # Description du fournisseur
        jdbcProviderType = "Oracle JDBC Driver"
        # Type de connexion
        implClassName = "oracle.jdbc.pool.OracleConnectionPoolDataSource"
        otherAttrsList = [
            ["classpath", prm_classpath],
            ["description", description],
            ["providerType", jdbcProviderType]
            ]

        log.info("Node : %s" % node)
        log.info("SA : %s" % sa)
        log.info("JDBC name : %s" % jdbcRessName)
        log.info("JNDI dans WAS: %s" % jndiWebName)
        log.info("URL datasource : %s" % urlOracle)
        log.info("Alias du compte : %s" % jdbcAliasAuth)
        log.info("Drivers : %s" % driversOracle)

        idJdbcProviderCreated = AdminJDBC.createJDBCProvider(
            node, sa, jdbcProviderName, implClassName, otherAttrsList)
        log.info("idJdbcProviderCreated : %s" % idJdbcProviderCreated)

    # Creation de l alias de connexion �  affecter � la datasource
    authList = _splitlines(AdminConfig.list('JAASAuthData'))

    if len(authList) != 0:
        for authAlias in authList:
            name_alias = AdminConfig.showAttribute(authAlias, 'alias')
            if name_alias == jdbcAliasAuth:
                log.warning("L'alias \"%s\" existe deja." % jdbcAliasAuth)
                existence_alias = 1

    if existence_alias == 0:
        # Creation de l alias de connexion � affecter � la datasource
        log.info("Alias : %s" % jdbcAliasAuth)
        log.info("Login : %s" % userOracle)
        log.info("Mot de passe : %s" % passOracle)
        descriptionAlias = "%s" % jdbcAliasAuth
        try:
            log.finer(
                "AdminResources.createJAASAuthenticationAlias("
                "\"%s\", \"%s\", \"%s\", \"%s\")"
                % (jdbcAliasAuth, userOracle, passOracle, descriptionAlias)
                )
            idAliasCreated = AdminResources.createJAASAuthenticationAlias(
                jdbcAliasAuth, userOracle, passOracle, descriptionAlias)
            log.info(
                "L alias de connexion a la datasource a ete cree "
                "(ID alias : %s)." % idAliasCreated
                )
        except:
            if userOracle == "":
                log.warning("Le nom du schema n a pas ete fourni.")
            if passOracle == "":
                log.warning("Le mot de passe du schema "
                            "n a pas ete fourni.")

    # Creation de la datasource
    properties = [
        [["name", "URL"], ["type", "java.lang.String"], ["value", urlOracle]]
        ]
    for p in dsProps:
        properties.append(p)
    
    mappingConfigAlias = "DefaultPrincipalMapping"
    otherAttrsList = [
        [
            'mapping',
            [
                ['authDataAlias', jdbcAliasAuth],
                ['mappingConfigAlias', mappingConfigAlias]
            ]
        ],
        ['description', jdbcRessName],
        ['jndiName', jndiWebName],
        ['authDataAlias', jdbcAliasAuth],
        [
            'datasourceHelperClassname',
            "com.ibm.websphere.rsadapter.Oracle11gDataStoreHelper"
        ],
        ['providerType', jdbcProviderType],
        ['propertySet', [["resourceProperties", properties]]]
        ]
    if len(poolProps) > 0:
        otherAttrsList.append(['connectionPool', poolProps])

    try:
        log.finer(
            "AdminJDBC.createDataSource(\"%s\", \"%s\", \"%s\", \"%s\", %s)"
            % (node, sa, jdbcProviderName, jdbcRessName, otherAttrsList)
            )
        idRessJdbcCreated = AdminJDBC.createDataSource(
            node, sa, jdbcProviderName, jdbcRessName, otherAttrsList
            )
        log.info("Ressource JDBC creee (ID = %s)" % idRessJdbcCreated)

    except:
        if urlOracle == "":
            log.severe("ERROR : la valeur de l instance "
                       "de la ressource n est pas specifiee !")
            flagErreur = 1
        if getCfgItemId("server", node, sa, "JDBCProvider:/DataSource",
                        "%s" % jdbcRessName) is not None:
            idRess = getCfgItemId("server", node, sa,
                                  "JDBCProvider:/DataSource",
                                  "%s" % jdbcRessName)
            log.warning("Cette ressource JDBC existe deja.")
            log.warning("Ancienne valeur : %s" % getUrlByDs(idRess))
            changeURLDatasource(idRess, urlOracle)
    log.fine("END createDs")


def createReeProvider(node, sa, corps_appli):
    """Creation uniquement d un fournisseur d environnement de ressources"""
    defaultResourceEnvProviderName = corps_appli + "_ENV"
    providerAlreadyExists = "False"
    listProviders = _splitlines(
        AdminConfig.list('ResourceEnvironmentProvider')
        )

    if listProviders is not None and listProviders != "":
        for provider in listProviders:
            name = AdminConfig.showAttribute(provider, 'name')
            if name == defaultResourceEnvProviderName:
                log.info("Le provider existe deja.")
                # providerMustToBeCreated = "True"
                providerAlreadyExists = "True"

    if providerAlreadyExists == "False":
        log.info("Creation du fournisseur de ressources :")
        idReeProviderCreated = AdminResources.createResourceEnvProvider(
            node, sa, defaultResourceEnvProviderName
            )
        log.info("idReeProviderCreated : %s" % idReeProviderCreated)
        log.info("Un nouveau fournisseur de ressources a �t� cr�e : %s"
                 % defaultResourceEnvProviderName)



def createReeProviderRef(node, sa, defaultResourceEnvProviderName,
                         factoryClass, className):
    """Creation d un fournisseur d environnement + fabrique + classe"""
    log.info("Creation pour le fournisseur en question "
             "d une fabrique de classes : ")
    idReeProviderReferenceablesCreated = (
        AdminResources.createResourceEnvProviderRef(
            node, sa, defaultResourceEnvProviderName, factoryClass, className
            )
        )
    log.info("idReeProviderReferenceablesCreated : "
             + idReeProviderReferenceablesCreated)
    return idReeProviderReferenceablesCreated


def createRee(node, sa, factoryClass, className,
              entryJndiName, cle, allProperties, appli):
    """Creation d une ressource d environnement"""
    global flagErreur
    # print("allProperties : %s" % allProperties)
    i = 0
    props = []

    for key, val in allProperties.items():
        p = props.append(val)

    nbProps = len(props)

    idServer = getServerId(node, sa)

    # Formatage du nom du fournisseur
    corps_appli = re.sub(r"(^SA_)?(^sa-)?(_app$)?(_pres$)?", r"", sa)
    defaultResourceEnvProviderName = corps_appli + "_ENV"
    # print("defaultResourceEnvProviderName : %s" % defaultResourceEnvProviderName)

    # Normally, as a first creation,
    # any provider should not exist for application, but in case
    listResourceEnvProviders = getObjectsOfType(
        "ResourceEnvironmentProvider", idServer)
    nbResourceEnvProviders = int(len(listResourceEnvProviders))

    # Creation du fournisseur d environnement
    if nbResourceEnvProviders == 0:
        createReeProvider(node, sa, corps_appli)

    # Creation de la fabrique et de la classe de fabriques
    # List all factories, check if already exists
    factoryToCreate = "yes"
    factoriesId = getObjectsOfType('Referenceable', '%s' % idServer)
    # print("factoriesId : %s" % factoriesId)
    if factoriesId:
        for factory in factoriesId:
            classname = AdminConfig.showAttribute(factory, 'classname')
            factoryClassname = AdminConfig.showAttribute(factory,
                                                         'factoryClassname')
            # print("classname : %s, factoryClassname : %s" % (classname,factoryClassname))
            if classname == className and factoryClassname == factoryClass:
                rf = factory
                factoryToCreate = "no"
    if factoryToCreate == "yes":
        rf = createReeProviderRef(
            node, sa, defaultResourceEnvProviderName, factoryClass, className
            )

    # Formatage du nom de la ressource d environnement
    resourceEnvEntryName = re.sub(r"^.*/", r"", entryJndiName)
    # EntryName = "env_" + corps_appli + "_" + resourceEnvEntryName + "_ENV"
    EntryName = corps_appli + "_" + resourceEnvEntryName + "_ENV"

    # Formatage du nom JNDI de l entree
    EntryJndi = "env/" + appli + "_" + resourceEnvEntryName + "_ENV"

    idEntries = _splitlines(
        getCfgItemId("server", node, sa,
                     "ResourceEnvironmentProvider:/ResourceEnvEntry")
        )
    jndiEntries = []

    if idEntries:
        for Entry in idEntries:
            jndiEntries.append(AdminConfig.showAttribute(Entry, 'jndiName'))

    if EntryJndi in jndiEntries:
        log.info(
            "La ressource d environnement %s existe : " % EntryJndi
            + "une mise a jour de ses proprietes va etre apportee"
            )
        Entry = idEntries[jndiEntries.index(EntryJndi)]
        nameEntry = AdminConfig.showAttribute(Entry, 'name')
        PropertySetEntryId = getObjectAttribute(Entry, 'propertySet')
        resourcePropertySetEntryIds = _splitlines(
            AdminConfig.list('J2EEResourceProperty', PropertySetEntryId)
            )

        log.info("Anciennes valeurs de l entree :")
        for resourceProperty in resourcePropertySetEntryIds:
            entryPropertyName = AdminConfig.showAttribute(resourceProperty,
                                                          'name')
            entryPropertyValue = AdminConfig.showAttribute(resourceProperty,
                                                           'value')
            log.info(
                "Nom : " + entryPropertyName
                + ", Valeur : " + entryPropertyValue
                )

        updateReeAction(Entry, EntryJndi, nameEntry, allProperties, node, sa)

    else:
        log.info("La ressource d environnement %s n'existe pas : " % EntryJndi
                 + "elle sera donc creee")
        attrEntry = [
            ['name', EntryName],
            ['jndiName', EntryJndi],
            ['referenceable', '%s' % rf]
            ]
        idReeEntry = AdminResources.createResourceEnvEntriesAtScope(
            "/Node:%s/Server:%s/" % (node, sa),
            defaultResourceEnvProviderName,
            EntryName,
            EntryJndi,
            attrEntry
            )
        log.info("L entree suivante a ete creee pour "
        	     "cette ressource d environnement : %s" % EntryName)

        log.info("Initialisation des valeurs de l entree en question :")
        ResourceReeEntriesIds = getObjectsOfType('ResourceEnvEntry', idServer)
        for ResourceReeEntryId in ResourceReeEntriesIds:
            ResourceReeEntryName = getObjectAttribute(ResourceReeEntryId,
                                                      'name')
            if ResourceReeEntryName == EntryName:
                ResourceReeEntryJndiName = getObjectAttribute(
                    ResourceReeEntryId, 'jndiName')
                ResourceReeEntryPropertySetId = getObjectAttribute(
                    ResourceReeEntryId, 'propertySet')

                # Creation du Set de proprietes
                if ResourceReeEntryPropertySetId is None:
                    ResourceReeEntryPropertySetId = AdminConfig.create(
                        'J2EEResourcePropertySet', ResourceReeEntryId, [])

                # Recuperation et creation des valeurs renseignees
                # pour la ressource d environnement
                while i < nbProps:
                    propName = props[i][0]
                    propValue = props[i][1]
                    log.info("Couple de valeurs : %s - %s"
                             % (propName, propValue))

                    name = ['name', propName]
                    value = ['value', propValue]
                    rpAttrs = [name, value]

                    idReePropertyCreated = AdminConfig.create(
                        'J2EEResourceProperty',
                        ResourceReeEntryPropertySetId,
                        rpAttrs
                        )
                    i += 1


def find_resource_id(scope, appli_name, type_ress, alt_jndi_name):
    log.fine("BEGIN find_resource_id(scope, appli_name,"
             "type_ress, alt_jndi_name)")
    log.fine("  scope = %s" % scope)
    log.fine("  appli_name = %s" % appli_name)
    log.fine("  type_ress = %s" % type_ress)
    log.fine("  alt_jndi_name = %s" % alt_jndi_name)
    id_ress = None

    if (type_ress == "url"):
        sa_ress_list = getObjectsOfType('URL', scope)
        jndi_name = ("url/" + appli_name
                     + "_" + re.sub(r"^.*/", r"", alt_jndi_name))
    elif (type_ress == "ds"):
        sa_ress_list = getObjectsOfType('DataSource', scope)
        jndi_name = ("jdbc/" + appli_name
                     + "_" + re.sub(r"^.*/", r"", alt_jndi_name))
    elif (type_ress == "ree"):
        sa_ress_list = getObjectsOfType('ResourceEnvEntry', scope)
        jndi_name = ("env/" + appli_name
                     + "_" + re.sub(r"^.*/", r"", alt_jndi_name) + "_ENV")

    log.finer("  sa_ress_list = %s" % sa_ress_list)
    log.finer("  jndi_name = %s" % jndi_name)

    for ress in sa_ress_list:
        jndi = getObjectAttribute(ress, 'jndiName')
        if jndi == jndi_name or jndi == alt_jndi_name:
            id_ress = ress

    log.fine("END find_resource_id - Returns : %s" % id_ress)
    return id_ress


def delete_action(type_ress, id_ress):
    log.fine("BEGIN delete_action(type_ress, id_ress)")
    log.fine("  type_ress = %s" % type_ress)
    log.fine("  id_ress = %s" % id_ress)
    global flagErreur
    log.info("Suppression de la ressource %s : %s" % (type_ress, id_ress))
    if type_ress == "url" or type_ress == "ree":
        if id_ress is None:
            log.info("La ressource n existe pas")
        else:
            try:
                AdminConfig.remove(id_ress)
                log.info("Suppression %s : OK" % type_ress)
            except:
                typ, val, tb = sys.exc_info()
                log.severe("Erreur lors de la suppression de la ressource :")
                log.severe("%s" % val)
                flagErreur = 1
    elif type_ress == "ds":
        if id_ress is None:
            log.info("La ressource n existe pas")
        else:
            auth = get_auth_data(id_ress)
            log.finer("  auth = %s" % auth)
            if auth is not None:
                try:
                    AdminConfig.remove(auth)
                except:
                    typ, val, tb = sys.exc_info()
                    log.severe("Erreur lors de la suppression de l alias :")
                    log.severe("%s" % val)
                    flagErreur = 1
            try:
                AdminConfig.remove(id_ress)
                log.info("Suppression ds : OK")
            except:
                typ, val, tb = sys.exc_info()
                log.severe("Erreur lors de la suppression de la ressource :")
                log.severe("%s" % val)
                flagErreur = 1
    log.fine("END delete_action")


def get_auth_data(ds):
    """Retourne l'alias d'une datasource"""
    log.finer("BEGIN get_auth_data(ds)")
    log.finer("  ds = %s" % ds)
    
    auth_alias = getObjectAttribute(ds, "authDataAlias")
    auth_list = getObjectsOfType("JAASAuthData")
    log.finest("  auth_alias = %s" % auth_alias)
    log.finest("  auth_list = %s" % auth_list)

    for auth in auth_list:
        alias = getObjectAttribute(auth, "alias")
        log.finest("  alias = %s" % alias)
        if alias == auth_alias:
            log.finer("END get_auth_data - Returns : %s" % auth)
            return auth

    log.warning("No auth data found for datasource %s" % ds)
    log.finer("END get_auth_data")


def set_auth_data(auth, user, pwd):
    """
    Modification des parametres de connexion a une base de donnees
    (Alias, user / pass)
    """
    log.finer("BEGIN set_auth_data(auth, user, pwd)")
    log.finer("  auth = %s" % auth)
    log.finer("  user = %s" % user)
    log.finer("  pwd = %s" % pwd)

    alias = getObjectAttribute(auth, "alias")
    current_user = getObjectAttribute(auth, "userId")
    current_pwd = getObjectAttribute(auth, "password")

    log.info("Modification de l'alias %s" % alias)
    log.info("User/Password actuel : %s / %s" % (current_user, current_pwd))
    log.info("Mise a jour en : %s / %s" % (user, pwd))

    AdminConfig.modify(auth, [['userId', user], ['password', pwd]])
    log.finer("END set_auth_data")


def view_datasource_properties(id_ress):
    """Visualisation d une ressource jdbc"""
    log.finer("BEGIN view_datasource_properties(id_ress)")
    log.finer("  id_ress = %s" % id_ress)
    jndi = getObjectAttribute(id_ress, 'jndiName')
    url = getUrlByDs(id_ress)
    auth = get_auth_data(id_ress)
    alias = getObjectAttribute(auth, 'alias')
    login = getObjectAttribute(auth, 'userId')
    # pwd = getObjectAttribute(auth, 'password')

    log.info("Nom JNDI defini dans WebSphere : %s" % jndi)
    log.info("Alias du schema : %s" % alias)
    log.info("Login du schema : %s" % login)
    log.info("Instance : %s" % url)
    log.finer("END view_datasource_properties")


def view_ree_properties(id_ress):
    log.finer("BEGIN view_ree_properties(id_ress)")
    log.finer("  id_ress = %s" % id_ress)
    """Visualisation d une ressource environnement"""
    provider = getObjectAttribute(id_ress, 'provider')
    log.finest("  provider = %s" % provider)
    log.info("Provider : %s" % getObjectAttribute(provider, 'name'))
    log.info(
        "Nom JNDI de l entree dans WAS : %s"
        % getObjectAttribute(id_ress, 'jndiName')
        )
    referenceable = getObjectAttribute(id_ress, 'referenceable')
    log.finest("  referenceable = %s" % referenceable)
    log.info("Fabrique : %s" % getObjectAttribute(referenceable,
                                                  'factoryClassname'))
    log.info("Classe : %s" % getObjectAttribute(referenceable, 'classname'))
    property_set = getObjectAttribute(id_ress, 'propertySet')
    resource_properties = _splitlines(
        AdminConfig.list('J2EEResourceProperty', property_set)
        )
    log.info("Valeurs de l entree :")
    for resource_property in resource_properties:
        property_name = AdminConfig.showAttribute(resource_property, 'name')
        property_value = AdminConfig.showAttribute(resource_property, 'value')
        log.info(
            "Nom : %s" % property_name
            + ", Valeur : %s" % property_value
            )
    log.finer("END view_ree_properties")


def view_action(type_ress, id_ress):
    """View ressource"""
    log.fine("BEGIN view_action(type_ress, id_ress)")
    log.fine("  type_ress = %s" % type_ress)
    log.fine("  id_ress = %s" % id_ress)
    if type_ress == "url":
        log.info("Nom JNDI dans WebSphere : %s"
              % getObjectAttribute(id_ress, 'jndiName'))
        log.info("Valeur : %s" % getObjectAttribute(id_ress, 'spec'))

    if type_ress == "ds":
        view_datasource_properties(id_ress)

    if type_ress == "ree":
        view_ree_properties(id_ress)
    log.fine("END view_action")

def delete_all_ressources(id_sa):
    log.fine("BEGIN delete_all_ressources(id_sa)")
    log.fine("  id_sa = %s" % id_sa)
    global flagErreur
    log.info("Suppression des ressources du sa %s" % (id_sa))
    url_list = _splitlines(AdminConfig.list('URL', id_sa))
    for id_url in url_list:
        delete_action("url", id_url)
    ds_list = _splitlines(AdminConfig.list('DataSource', id_sa))
    for id_ds in ds_list:
        delete_action("ds", id_ds)
    jdbc_provider_list = _splitlines(AdminConfig.list('JDBCProvider', id_sa))
    for p in jdbc_provider_list:
        log.info("Suppression du Provider : %s" % p)
        try:
            AdminConfig.remove(p)
        except:
            typ, val, tb = sys.exc_info()
            log.severe("Erreur suppression du Provider JDBC : %s " % p)
            log.severe("%s" % val)
            flagErreur = 1
    ree_provider_list = _splitlines(
        AdminConfig.list('ResourceEnvironmentProvider', id_sa)
        )
    for p in ree_provider_list:
        log.info("Suppression du provider ResourceEnvironment : %s" % p)
        try:
            AdminConfig.remove(p)
        except:
            typ, val, tb = sys.exc_info()
            log.severe(
                "Erreur suppression du provider ResourceEnvironment : %s" % p
                )
            log.severe("%s" % val)
            flagErreur = 1
    log.fine("END delete_all_ressources")
