#-------------------------
# Librairies de fonctions
#------------------------
import os
import re
import time
import javax.management as mgmt

sys.path.append(os.environ["ROOT_DIR"] + "/python")
from functions import *

#--------------------
# PROGRAMME PRINCIPAL
#--------------------

SA_NAME = sys.argv[0] # SA name provided : SA_nrj-itest3_app

cellule  = getCellId()
cellName = getCellName()
nodes = getObjectsOfType('Node', cellule)

recherche = 'UNKNOWN'

appServers = getObjectsOfType('Server')
for server in appServers:
    servers = getObjectAttribute(server, "name")
    if SA_NAME == servers:
        SAid = server # SA ID
        posStringNode = SAid.find("nodes")
        posFin = SAid.find("/", posStringNode + 6)
        nodeName = SAid[posStringNode+6:posFin] # Node's SA
        serverName = SA_NAME
        recherche = 'FOUND'

if (recherche == "FOUND"):
    apps = listAppOfSA(cellName, nodeName, serverName)
    nbApps = int(len(apps))

    if (nbApps > 0):
        for appli in apps:
            if appli != "ibmasyncrsp":
                print "Application : ", appli
                print ""
                idJVM = AdminConfig.list('JavaVirtualMachine', SAid)

                get_ds_list(SAid, appli)
                get_url_list(SAid, appli)
                get_ree_list(SAid, appli)
    else:
        print 'WARNING : No application installed !'
        sys.exit(8)
else :
    print '\nERROR : This application server \"' + SA_NAME + '\" has not been found. Please check the name given.'
    sys.exit(2)
