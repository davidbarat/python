# -*- coding: utf-8 -*
import os
import sys

sys.path.append(os.environ["ROOT_DIR"] + "/python")
from customlog import define_logger
from functions import *
from functions import _splitlines, _splitlist

# Logging configuration
log = define_logger("managesa", "INFO")

propsFile = sys.argv[0]


def find_max_port(server_entries, new_sa_name):
    """Return the maximum BOOTSTRAP_ADDRESS port used in the cell.

    server_entries -- List of all the servers in the cell
    new_sa_name -- Name of the SA to create

    """
    global AdminConfig
    max_port = 0

    log.info("Find starting port for new SA %s" % new_sa_name)

    for server_entry in server_entries:
        server_name = AdminConfig.showAttribute(server_entry, 'serverName')
        server_type = AdminConfig.showAttribute(server_entry, 'serverType')

        if server_type != "WEB_SERVER" and server_name != new_sa_name:
            special_endpoints = _splitlist(
                AdminConfig.showAttribute(server_entry, 'specialEndpoints')
                )[0]

            if special_endpoints != "" and special_endpoints is not None:
                special_endpoint = [special_endpoints][0]
                endpoint_name = AdminConfig.showAttribute(
                    special_endpoint, 'endPointName'
                    )
                endpoint = AdminConfig.showAttribute(special_endpoint,
                                                     'endPoint')
                port = AdminConfig.showAttribute(endpoint, 'port')

                if max_port < port:
                    max_port = port

    return max_port


def check_port(server_entry, port):
    """Check if a port is used by a server.

    server_entry -- The server
    port -- Port to check

    """
    global AdminConfig
    special_endpoints = [
        _splitlist(
            AdminConfig.showAttribute(server_entry, 'specialEndpoints')
            )[0]
        ]

    for special_endpoint in special_endpoints:
        endpoint_name = AdminConfig.showAttribute(
            special_endpoint, 'endPointName'
            )
        endpoint = AdminConfig.showAttribute(special_endpoint, 'endPoint')
        endpoint_port = AdminConfig.showAttribute(endpoint, 'port')

        if port == endpoint_port or eval('port + 10') == endpoint_port:
            log.severe(
                "ERROR: port range "
                + AdminConfig.showAttribute(server_entry, 'serverName')
                + " already in use by server " + port
                + " by " + endpoint_name + " : " + endpoint_port
                )
            sys.exit(1)


def set_port(server_entry, starting_port,
             ports_to_modify, ports_to_delete):
    """Set the application server ports.

    server_entry -- The application server
    starting_port -- Start of the port range
    ports_to_modify -- String of ports to modify
    ports_to_delete -- String of ports to delete

    """
    global AdminConfig

    special_endpoints = _splitlines(
        _splitlist(
            AdminConfig.showAttribute(server_entry, 'specialEndpoints')
            )
        )[0]

    log.info("starting_port : %s" % starting_port)

    ports_to_delete = "[" + ports_to_delete + "]"
    list_ports_to_delete = _splitlist(ports_to_delete)
    log.finest("list_ports_to_delete : %s" % list_ports_to_delete)

    ports_to_modify = "[" + ports_to_modify + "]"
    list_ports_to_modify = _splitlist(ports_to_modify)
    log.finest("list_ports_to_modify : %s" % list_ports_to_modify)

    compteur = 1
    # Configure les ports
    for special_endpoint in special_endpoints:
        endpoint_name = AdminConfig.showAttribute(special_endpoint,
                                                  'endPointName')
        endpoint = AdminConfig.showAttribute(special_endpoint, 'endPoint')
        endpoint_host = AdminConfig.showAttribute(endpoint, 'host')
        endpoint_port = AdminConfig.showAttribute(endpoint, 'port')

        # Delete some endPoints
        if endpoint_name in list_ports_to_delete:
            log.info(
                "Remove EndPoint : "
                + endpoint_name
                + " (" + special_endpoint + ")"
                )
            AdminConfig.remove(special_endpoint)

        # Configure endpoint_name ports
        if endpoint_name in list_ports_to_modify:
            log.finest("endpoint_name : %s" % endpoint_name)
            log.finest("Port actuel : %s" % endpoint_port)
            new_port = int(starting_port) + int(compteur)
            log.finest("Nouveau port : %s" % new_port)
            AdminConfig.modify(
                endpoint,
                [['host', endpoint_host], ['port', new_port]]
                )
            compteur = compteur + 1


def set_server_ports(server_id, server_entries):
    """Set the application server ports.

    server_id -- Id of the server
    server_entries -- List of all the servers in the cell

    """
    global prm_listPortToModify, prm_listPortToDelete
    global prm_listTransportChainToDelete, prm_portRangeWide

    new_sa_name = AdminConfig.showAttribute(server_id, 'name')
    log.info("new_sa_name : %s" % new_sa_name)

    max_port = find_max_port(server_entries, new_sa_name)
    log.info("Maximum port found : %s" % max_port)
    log.info("Port range : %s" % prm_portRangeWide)
    starting_port = int(max_port) + int(prm_portRangeWide)
    log.info("New SA ports start at : %s" % starting_port)

    log.info("Verifying possible port conflicts...")
    for server_entry in server_entries:
        server_name = AdminConfig.showAttribute(server_entry, 'serverName')
        # if server_name != new_sa_name:
        check_port(server_entry, starting_port)

    if prm_listTransportChainToDelete != "":
        log.info(
            "Removing transport chain %s..." % prm_listTransportChainToDelete
            )
        prm_listTransportChainToDelete = (
            "[" + prm_listTransportChainToDelete + "]"
            )
        listTransportChainToDelete = _splitlist(
            prm_listTransportChainToDelete
            )
        tpservs = AdminConfig.list('Chain', server_id).split('\n')
        for tpserv in tpservs:
            tpservName = AdminConfig.showAttribute(tpserv, 'name')
            if tpservName in listTransportChainToDelete:
                log.info("Remove %s (%s)" % (tpservName, tpserv))
                AdminConfig.remove(tpserv)

    # Parcourt les serveurs pour trouver notre serveur
    log.info("Setting TCP ports...")
    for server_entry in server_entries:
        server_name = AdminConfig.showAttribute(server_entry, 'serverName')
        if server_name == new_sa_name:
            # Configure les ports
            log.info(
                "===> Setting ports (deleting some useless ports : "
                + prm_listPortToDelete
                + ") ..."
                )
            set_port(
                server_entry, starting_port,
                prm_listPortToModify, prm_listPortToDelete
                )


def set_logs(node_name, server_name, server_log_root):
    """Set the SERVER_LOG_ROOT variable in the server scope.

    node_name -- Name of the node
    server_name -- Name of the server
    server_log_root -- New value for SERVER_LOG_ROOT

    """
    global AdminConfig
    global prm_logType

    log.info("logType value : %s" % prm_logType)

    # VariableMap
    var_map = AdminConfig.getid(
        '/Node:%s/Server:%s/VariableMap:/' % (node_name, server_name)
        )

    # VariableSubstitutionEntries list
    vs_list = _splitlist(AdminConfig.showAttribute(var_map, 'entries'))

    for vs in vs_list:
        symbolic_name = AdminConfig.showAttribute(vs, 'symbolicName')
        if symbolic_name == "SERVER_LOG_ROOT":
            AdminConfig.modify(vs, [['value', server_log_root]])
            log.info("%s is now : %s" % (symbolic_name, server_log_root))


def set_jvm_parameters(server_id, initial_heap_size,
                       maximum_heap_size, classpath, generic_arguments):
    """Set the JVM parameters.

    server_id -- Id of the server
    initial_heap_size -- JVM initial size (Mo)
    maximum_heap_size -- JVM max size (Mo)
    classpath -- JVM classpath
    generic_arguments -- Generic JVM arguments

    """
    global AdminConfig
    jvm = AdminConfig.list('JavaVirtualMachine', server_id)

    log.info("Setting JVM parameters...")

    # Heap size
    AdminConfig.modify(
        jvm,
        [
            ['initialHeapSize', initial_heap_size],
            ['maximumHeapSize', maximum_heap_size]
        ]
        )
    log.info(
        "Memory heap size is now : "
        + initial_heap_size + "/" + maximum_heap_size
        + " Mo (Initial / Max)"
        )

    # Generic arguments
    if generic_arguments == "":
        AdminConfig.modify(jvm, [['genericJvmArguments', '']])
    else:
        AdminConfig.modify(
            jvm, [['genericJvmArguments', generic_arguments]]
            )
        log.info("Generic arguments are now : %s" % generic_arguments)

    # Classpath
    if classpath == "":
        AdminConfig.modify(jvm, [['classpath', ""]])
    else:
        AdminConfig.modify(jvm, [['classpath', classpath]])
        log.info("Classpath is now : %s" % classpath)


def set_orb(server_id, request_timeout, locaterequest_timeout, was_version):
    """Configure the object request broker.

    server_id -- Id of the server
    request_timeout -- Request timeout (s)
    locaterequest_timeout -- locateRequest timeout (s)
    was_version -- WAS version

    """
    global AdminConfig
    orb = AdminConfig.list('ObjectRequestBroker', server_id)

    log.info("Setting ORB properties...")

    AdminConfig.modify(
        orb,
        [
            ['requestTimeout', request_timeout],
            ['locateRequestTimeout', locaterequest_timeout]
        ]
        )
    log.info("Request timeout is now : %s s" % request_timeout)
    log.info("LocateRequest timeout is now : %s s" % locaterequest_timeout)

    if was_version != "6.0":
        AdminConfig.modify(orb, [['useServerThreadPool', 'true']])
        log.info("useServerThreadPool is now : true")


def set_custom_properties(server_id, properties):
    """Set the JVM custom properties.

    server_id -- Id of the server
    properties -- List of the custom properties

    """
    global AdminConfig
    jvm = AdminConfig.list('JavaVirtualMachine', server_id)

    log.info("Setting JVM custom properties...")

    # AdminConfig.create('Property', jvm, [])
    # AdminConfig.create('Property', jvm, prm_jvmprop)
    AdminConfig.modify(jvm, [['systemProperties', ""]])
    AdminConfig.modify(jvm, [['systemProperties', properties]])
    log.info("Custom properties are now : %s" % properties)


def set_backup(server_id, number_of_files, rollover_size):
    """Configure the log rotation.

    server_id -- Id of the server
    number_of_files -- Number of archived log files
    rollover_size -- Size of log files (Mo)

    """
    global AdminConfig
    global prm_logType

    log.info("Setting nb backup logs...")

    if prm_logType == "B":
        outputStream = AdminConfig.showAttribute(server_id,
                                                 'outputStreamRedirect')
        AdminConfig.modify(
            outputStream,
            [
                ['maxNumberOfBackupFiles', number_of_files],
                ['rolloverSize', rollover_size]
            ]
            )
        log.info(
            "System.out maxNumberOfBackupFiles is now : %s"
            % number_of_files
            )
        log.info("System.out rolloverSize is now : %s Mo" % rollover_size)

        errorStream = AdminConfig.showAttribute(server_id,
                                                'errorStreamRedirect')
        AdminConfig.modify(
            errorStream,
            [
                ['maxNumberOfBackupFiles', number_of_files],
                ['rolloverSize', rollover_size]
            ]
            )
        log.info(
            "System.err maxNumberOfBackupFiles is now : %s"
            % number_of_files
            )
        log.info("System.err rolloverSize is now : %s Mo" % rollover_size)


def set_webcontainer_props(server_id, properties):
    """Set the Web Container properties.

    server_id -- Id of the server
    properties -- List of the web container properties

    """
    global AdminConfig

    log.info("Setting WebContainer properties...")

    wc = AdminConfig.list('WebContainer', server_id)
    AdminConfig.modify(wc, [['properties', ""]])
    AdminConfig.modify(wc, [['properties', properties]])
    # AdminConfig.create('Property', wc, properties)
    log.info("WebContainer properties are now : %s" % properties)


def set_webplugin_properties(server_id, timeout):
    """Set the Web server plug-in properties.

    server_id -- Id of the server
    timeout -- Connection timeout (s)

    """
    global AdminConfig

    log.info("Setting web server plugin properties...")

    web_plugin = AdminConfig.list('WebserverPluginSettings', server_id)
    AdminConfig.modify(
        web_plugin,
        [['ConnectTimeout', timeout]]
        )
    log.info("Connect timeout is now : %s (s)" % timeout)


def set_env(server_id, env_entries):
    """Set the JVM environment entries.

    server_id -- Id of the server
    env_entries -- List of the environment entries

    """
    global AdminConfig

    log.info("Setting environment entries...")

    process_def = AdminConfig.list('ProcessDef', server_id)
    AdminConfig.modify(process_def, [['environment', ""]])
    AdminConfig.modify(process_def, [['environment', env_entries]])
    log.info("Environment entries are now : %s" % env_entries)


def set_process_execution(server_id):
    """Set the JVM process execution.

    server_id -- Id of the server

    """
    global AdminConfig
    global prm_processPriority, prm_umask

    log.info("Setting process execution properties...")

    process_def = AdminConfig.list('ProcessDef', server_id)
    process_exec = AdminConfig.showAttribute(process_def, 'execution')
    AdminConfig.modify(
        process_exec,
        [
            ['processPriority', prm_processPriority],
            ['umask', prm_umask]
        ]
        )
    log.info("Process priority is now : %s" % prm_processPriority)
    log.info("Umask is now : %s" % prm_umask)


def set_threadpool_properties(threadpool, timeout, is_growable,
                              maximum_size, minimum_size):
    """Set the ThreadPool properties.

    server_id -- Id of the server
    timeout -- Inactivity timeout
    is_growable -- Boolean
    maximum_size -- Maximum size of the ThreadPool
    minimum_size -- Minimum size of the ThreadPool

    """
    global AdminConfig

    threadpool_name = AdminConfig.showAttribute(threadpool, 'name')
    log.info("Setting %s thread pool properties..." % threadpool_name)

    AdminConfig.modify(
        threadpool,
        [
            ['inactivityTimeout', timeout],
            ['isGrowable', is_growable],
            ['maximumSize', maximum_size],
            ['minimumSize', minimum_size]
        ]
        )
    log.info("Inactivity timeout is now : %s" % timeout)
    log.info("IsGrowable is now : %s" % is_growable)
    log.info("Maximum size is now : %s" % maximum_size)
    log.info("Minimum size is now : %s" % minimum_size)


def set_transaction_service_properties(server_id, client_timeout,
                                       transaction_lifetime, log_directory):
    """Set the ThreadPool properties.

    server_id -- Id of the server
    client_timeout -- Client inactivity timeout (s)
    transaction_lifetime -- Total transaction lifetime timeout (s)
    log_directory -- Transaction log directory

    """
    global AdminConfig
    log.info("Setting transaction service properties...")
    tran_id = AdminConfig.list('TransactionService', server_id)
    tran_attrs = [
        ['clientInactivityTimeout', client_timeout],
        ['totalTranLifetimeTimeout', transaction_lifetime]
        ]

    if log_directory != "DEFAULT":
        tran_attrs.append(
            ['transactionLogDirectory', log_directory]
            )
    AdminConfig.modify(tran_id, tran_attrs)

    log.info("clientInactivityTimeout is now : %s s" % client_timeout)
    log.info("totalTranLifetimeTimeout is now : %s s" % transaction_lifetime)
    if log_directory != "DEFAULT":
        log.info(
            "transactionLogDirectory is now : " + log_directory
            )


def set_custom_property(server_id, prop_name, prop_value):
    """Set one JVM custom property.

    server_id -- Id of the server
    prop_name -- Property name
    prop_value -- Property value

    """
    global AdminConfig
    log.info("Setting JVM custom property...")
    attrs = [['name', prop_name], ['value', prop_value]]
    prop_found = "false"
    jvm = AdminConfig.list('JavaVirtualMachine', server_id)

    for prop_id in _splitlines(AdminConfig.list('Property', jvm)):
        tmp_name = AdminConfig.showAttribute(prop_id, 'name')
        if tmp_name == prop_name:
            prop_found = "true"
            tmpValue = AdminConfig.showAttribute(prop_id, 'value')
            if tmpValue == prop_value:
                log.info(
                    "Custom property \"" + prop_name
                    + "\" is already set to : " + prop_value
                    )
            else:
                AdminConfig.modify(prop_id, attrs)
                log.info(
                    "Custom property \"" + prop_name
                    + "\" is now : " + prop_value
                    )

    if prop_found == "false":
        AdminConfig.create('Property', jvm, attrs)
        log.info(
            "Custom property \"%s\" is now : %s" % (prop_name, prop_value))


def set_hamanager_properties(server_id, enable_service):
    """Set HA Manager properties.

    server_id -- Id of the server
    enable_service -- Boolean

    """
    global AdminConfig

    log.info("Setting HA Manager Service...")
    hmgr_id = AdminConfig.list('HAManagerService', server_id)
    AdminConfig.modify(hmgr_id, [['enable', enable_service]])
    if enable_service == "false":
        log.info("HAManager Service is disabled.")
    else:
        log.info("HAManager Service is enabled.")


def set_attach_api(server_id, flag):
    """Set "com.ibm.tools.attach.enable" JVM custom property.

    server_id -- Id of the server
    flag -- Value of "com.ibm.tools.attach.enable" (boolean)

    """
    global AdminConfig
    prop_name = "com.ibm.tools.attach.enable"
    if flag == "true":
        prop_value = "yes"
    else:
        prop_value = "no"
    set_custom_property(server_id, prop_name, prop_value)


def config_jvm_classloader(server_id, jvm_classloader, jvm_classloader_mode,
                           jvm_classloader_sharedlib):
    """Configure JVM classloader.

    server_id -- Id of the server
    jvm_classloader -- Boolean (?)
    jvm_classloader_mode --
    jvm_classloader_sharedlib --

    """
    global AdminConfig
    for cl in AdminConfig.list('Classloader', server_id):
        AdminConfig.remove(cl)
    appServerId = AdminConfig.list('ApplicationServer', server_id)
    clId = AdminConfig.create(
        'Classloader',
        appServerId,
        [['mode', jvm_classloader_mode]]
        )
    for lib in jvm_classloader_sharedlib:
        AdminConfig.create(
            'LibraryRef',
            clId,
            [
                ['libraryName', lib],
                ['sharedClassloader', 'true']
            ]
            )


def set_server_config(server_id):
    """Configure the application server.

    server_id -- Id of the server

    """
    global AdminConfig
    global prm_initialHeapSize, prm_maximumHeapSize, \
        prm_classpath, prm_genericJvmArguments
    global prm_orbReqTO, prm_orbLocReqTO
    global prm_jvmprop
    global prm_nbBackupLog, prm_rolloverSize
    global prm_wcprop, prm_processEnv, prm_gcPolicy
    global prm_processPriority, prm_umask, prm_workingDirectory
    global prm_tporbInactivityTimeout, prm_tporbIsGrowable,\
        prm_tporbMaximumSize, prm_tporbMinimumSize
    global prm_tpwebInactivityTimeout, prm_tpwebIsGrowable,\
        prm_tpwebMaximumSize, prm_tpwebMinimumSize
    global prm_WAS_VERSION, prm_nodeTempDir, prm_pluginConnectTimeout
    global prm_clientInactivityTimeout, prm_totalTranLifetimeTimeout,\
        prm_transactionLogDirectory, prm_enableHAManagerService,\
        prm_enableJavaAttachAPI
    global prm_sessionPersistenceMode, prm_sessionPersistenceDataSource,\
        prm_sessionPersistenceUser, prm_sessionPersistencePassword
    global prm_jvmClassLoader, prm_jvmClassLoaderMode,\
        prm_jvmClassLoaderSharedLibrary

    set_jvm_parameters(server_id, prm_initialHeapSize, prm_maximumHeapSize,
                       prm_classpath, prm_genericJvmArguments)

    set_orb(server_id, prm_orbReqTO, prm_orbLocReqTO, prm_WAS_VERSION)

    # Change WAS temporary directory
    # if prm_nodeTempDir != "DEFAULT":
    #     print "Setting WAS temporary directory..."
    #     set_custom_properties(server_id, prm_jvmprop, prm_nodeTempDir)
    set_custom_properties(server_id, prm_jvmprop)

    set_backup(server_id, prm_nbBackupLog, prm_rolloverSize)

    if prm_wcprop != "":
        set_webcontainer_props(server_id, prm_wcprop)

    set_webplugin_properties(server_id, prm_pluginConnectTimeout)

    if prm_processEnv != "":
        set_env(server_id, prm_processEnv)

    set_process_execution(server_id)

    for tp in _splitlines(AdminConfig.list('ThreadPool', server_id)):
        name = AdminConfig.showAttribute(tp, 'name')
        if name == "ORB.thread.pool":
            set_threadpool_properties(tp, prm_tporbInactivityTimeout,
                                      prm_tporbIsGrowable,
                                      prm_tporbMaximumSize,
                                      prm_tporbMinimumSize)
        if name == "WebContainer":
            set_threadpool_properties(tp, prm_tpwebInactivityTimeout,
                                      prm_tpwebIsGrowable,
                                      prm_tpwebMaximumSize,
                                      prm_tpwebMinimumSize)

    set_transaction_service_properties(server_id, prm_clientInactivityTimeout,
                                       prm_totalTranLifetimeTimeout,
                                       prm_transactionLogDirectory)

    set_hamanager_properties(server_id, prm_enableHAManagerService)

    if prm_WAS_VERSION >= 70:
        set_attach_api(server_id, prm_enableJavaAttachAPI)

    # if prm_WAS_VERSION >= 61:
    #     enableCustomPMI( server_id )
    #         instrument( server_id )
    #         applySharedClassesSettings( server_id )
    #         setGcPolicy(server_id, prm_gcPolicy)
    #         removeRMIConnector( server_id )

    # positionne le repertoire de travail
    process_def = AdminConfig.list('ProcessDef', server_id)
    log.info("Setting working directory to '%s'" % prm_workingDirectory)
    AdminConfig.modify(
        process_def,
        [['workingDirectory', prm_workingDirectory]]
        )

    # session persistence
#    sm = AdminConfig.list('SessionManager', server_id)
#    if prm_sessionPersistenceMode == "N":
#        print "Disabling session persistence"
#        AdminConfig.modify(sm, [['sessionPersistenceMode', "NONE"]])
#    elif prm_sessionPersistenceMode == "DB":
#        print "Enable session persistence to Database"
#        AdminConfig.modify(sm, [['sessionPersistenceMode', 'DATABASE']])
#        sesdb = AdminConfig.list('SessionDatabasePersistence', sm)
#        AdminConfig.modify(sesdb, [['userId', prm_sessionPersistenceUser], ['password', prm_sessionPersistencePassword], ['tableSpaceName', ""], ['datasourceJNDIName', prm_sessionPersistenceDataSource]])
#
#    if prm_WAS_VERSION >= 61:
#        config_jvm_classloader(server_id, prm_jvmClassLoader, prm_jvmClassLoaderMode, prm_jvmClassLoaderSharedLibrary)


def set_server_sdk(node_name, server_name, version):
    """Set the SDK version of the application server.

    node_name -- Name of the node
    server_name -- Name of the server
    version -- SDK version to set

    """
    sdk_list = _splitlines(
        AdminTask.getAvailableSDKsOnNode('[-nodeName %s]' % node_name)
        )
    for sdk_name in sdk_list:
        if sdk_name.find(version) == 0:
            AdminTask.setServerSDK(
                '[-nodeName %s -serverName %s -sdkName %s]'
                % (node_name, server_name, sdk_name)
                )
            break


def config_existing_server(node_name, server_name, server_log_root):
    """Configure the application server.

    server_id -- Id of the server
    server_name -- Name of the server
    server_log_root -- Log directory

    """
    global AdminConfig, prm_WAS_VERSION, prm_webBindingAddress
    server_id = AdminConfig.getid(
        '/Node:%s/Server:%s/' % (node_name, server_name)
        )
    set_server_config(server_id)
    set_server_sdk(node_name, server_name, "1.7")

    if server_log_root != "DEFAULT":
        log.info("Setting logs root...")
        set_logs(node_name, server_name, server_log_root)

    if prm_WAS_VERSION >= 61:
        global AdminTask
        log.info(
            "Setting WC_defaulthost host to %s..." % prm_webBindingAddress)
        AdminTask.modifyServerPort(
            server_name,
            [
                '-nodeName', node_name,
                '-endPointName', 'WC_defaulthost',
                '-host', prm_webBindingAddress,
                '-modifyShared', 'true'
            ]
            )


def create_virtualhost(sa_name):
    """Create a virtual host for the application server.

    sa_name -- Name of the server

    """
    global AdminConfig, prm_webserverVip, prm_webserverUrl,\
        prm_webserverPort, prm_webserverPortSSL
    log.info("VIRTUAL HOST creation...")
    corps_appli = re.sub(r"(^SA_)?(^sa-)?(_app$)?(_pres$)?", r"", sa_name)
    vh_name = corps_appli + "_vh"
    log.info("Nom du VH : %s" % vh_name)
    log.info("Valeurs par defaut :")
    log.info("%s / %s" % (prm_webserverVip, prm_webserverPort))
    log.info("%s / %s" % (prm_webserverVip, prm_webserverPortSSL))

    sw_full_hostname = prm_webserverHost + ".fr.net.intra"

    vh_aliases = (
        "[['hostname' " + prm_webserverVip + "],"
        + "['port' " + prm_webserverPort + "]] "
        + "[['hostname' " + prm_webserverHost + "],"
        + "['port' " + prm_webserverPortSSL + "]] "
        + "[['hostname' " + sw_full_hostname + "],"
        + "['port' " + prm_webserverPort + "]] "
        + "[['hostname' " + sw_full_hostname + "],"
        + "['port' " + prm_webserverPortSSL + "]] "
        + "[['hostname' " + prm_webserverUrl + "],"
        + "['port' " + prm_webserverPort + "]] "
        + "[['hostname' " + prm_webserverUrl + "],"
        + "['port' " + prm_webserverPortSSL + "]] "
        + "[['hostname' " + prm_webserverHost + "],['port' '80']] "
        + "[['hostname' " + sw_full_hostname + "],['port' '80']] "
        + "[['hostname' " + prm_webserverUrl + "],['port' '80']] "
        + "[['hostname' " + prm_webserverHost + "],['port' '443']] "
        + "[['hostname' " + sw_full_hostname + "],['port' '443']] "
        + "[['hostname' " + prm_webserverUrl + "],['port' '443']]"
        )

    log.info("START")
    vh_to_create = 1
    virtualhosts = _splitlines(AdminConfig.list('VirtualHost'))
    for vh in virtualhosts:
        temp_vh_name = AdminConfig.showAttribute(vh, 'name')
        if temp_vh_name == vh_name:
            log.info("Similar virtual host already exists")
            if os.environ["ARA_FLAG"] == "true" and prm_webserverPort != "-1" :
                AdminConfig.remove(vh)
                log.info("Existing virtual host has been deleted")
            else:
                vh_to_create = 0
            break

    if vh_to_create == 1:
        log.info("Creating virtual host %s" % vh_name)
        cell = AdminConfig.list('Cell')
        vhost = AdminConfig.create('VirtualHost', cell,
                                   [['name', vh_name]])
        AdminConfig.modify(vhost, [['aliases', vh_aliases]])
        AdminConfig.save()
        log.info("DONE")
    else:
        log.info("NOT DONE")


def create_sharedlibs(node_name, server_name):
    """Create shared librairies in the application server scope.

    node_name -- Name of the node
    server_name -- Name of the application server

    """
    global AdminConfig
    global prm_description, prm_libclassPath,\
        prm_libNativePath, prm_libIsolatedClassLoader

    obj_id = ""
    lib_id = ""
    corps_appli = re.sub(r"(^SA_)?(^sa-)?(_app$)?(_pres$)?", r"", server_name)
    lib_name = corps_appli + "_shared"
    lib_description = lib_name + " shared Librairies"

    log.info("SHARED LIBRARY creation ...")
    log.info(
        "Creation of the library,\"" + lib_name + "\","
        + "for " + node_name + "/" + server_name
        )
    obj_id = AdminConfig.getid(
        '/Node:%s/Server:%s' % (node_name, server_name)
        )
    lib_id = AdminConfig.getid(
        "/Node:" + node_name
        + "/Server:" + server_name
        + "/Library:" + lib_name
        )

    if obj_id == "":
        log.severe("Invalid scope : unknown node or server name !")
        sys.exit(1)

    name = ['name', lib_name]
    description = ['description', lib_description]
    classpath = ['classPath',  prm_libclassPath]
    nativepath = ['nativePath', prm_libNativePath]

    icl = ['isolatedClassLoader', prm_libIsolatedClassLoader]
    parameters = [name, description, classpath, nativepath, icl]

    server_id = AdminConfig.getid(
        '/Node:%s/Server:%s/' % (node_name, server_name)
        )
    if server_id == "":
        log.warning(
            "Cannot create shared librairies "
            + "because application server does not exist."
            )
        log.warning("NOT DONE")
    else:
        if lib_id != "":
            log.warning("Shared library \"%s\" already exists !" % lib_name)
            log.warning("NOT DONE")
        else:
            AdminConfig.create('Library', obj_id, parameters)
            AdminConfig.save()
            log.info("DONE")


def set_webserver_config(webserver_id, webserver_parent):
    """Configure the web server.

    webserver_id -- Id of the web server
    webserver_parent -- Web server parent

    """
    global AdminConfig
    global prm_pluginlogFilename, prm_pluginInstallRoot,\
        prm_pluginRefreshInterval, prm_pluginLogLevel
    global prm_pluginProperties, prm_pluginLoadBalance,\
        prm_pluginRetryInterval
    global prm_webConfigurationFilename

    prm_pluginlogFilename = prm_LOGS_IHS_DIR + "/http-plugin.log"

    pgin = AdminConfig.list('PluginProperties', webserver_id)

    AdminConfig.modify(pgin, [['LogFilename', prm_pluginlogFilename]])
    AdminConfig.modify(pgin, [['PluginInstallRoot', prm_pluginInstallRoot]])
    AdminConfig.modify(pgin, [['RefreshInterval', prm_pluginRefreshInterval]])
    AdminConfig.modify(pgin, [['LogLevel', prm_pluginLogLevel]])
    AdminConfig.modify(pgin, [['PluginGeneration', 'MANUAL']])
    AdminConfig.modify(pgin, [['PluginPropagation', 'MANUAL']])

    AdminConfig.modify(pgin, [['properties', []]])
    if prm_pluginProperties != "":
        AdminConfig.modify(pgin, [['properties', prm_pluginProperties]])

    pscp = AdminConfig.list('PluginServerClusterProperties', pgin)
    AdminConfig.modify(pscp, [['LoadBalance', prm_pluginLoadBalance]])
    AdminConfig.modify(pscp, [['RetryInterval', prm_pluginRetryInterval]])

    process_def = AdminConfig.list('ProcessDef', webserver_parent)
    AdminConfig.modify(process_def, [['startCommandArgs', ""]])
    AdminConfig.modify(process_def, [['stopCommandArgs', ""]])
    start_cmd = "-k start -f %s" % prm_webConfigurationFilename
    stop_cmd = "-k stop -f %s" % prm_webConfigurationFilename
    AdminConfig.modify(process_def, [['startCommandArgs', [start_cmd]]])
    AdminConfig.modify(process_def, [['stopCommandArgs', [stop_cmd]]])


def set_host(server_entry, hostname):
    """Define the web server hostname.

    server_entry -- The web server
    hostname -- The hostname

    """
    global AdminConfig
    special_endpoints = _splitlines(
        _splitlist(AdminConfig.showAttribute(server_entry, 'specialEndpoints'))
        )[0]

    for special_endpoint in special_endpoints:
        endpoint = AdminConfig.showAttribute(special_endpoint, 'endPoint')
        AdminConfig.modify(endpoint, [['host', hostname]])
        value = AdminConfig.show(endpoint)
    AdminConfig.save()


def create_webserver(node_name, sa_name, vip,
                     port, host, was_version):
    """Create a web server.

    node_name -- The node name
    sa_name -- The application server name
    vip -- The web server vip
    port -- The web server port
    host -- The web server host
    was_version -- The WAS version

    """
    global prm_webConfigurationFilename, prm_webLogFilenameError,\
        prm_webLogFilenameAccess, prm_webserverName

    corps_appli = re.sub(
        r"(^SA_)?(^sa-)?(_app$)?(_pres$)?", r"", sa_name
        )

    was_version = int(was_version)

    if was_version >= 85:
        prm_webserverName = "sw-" + corps_appli
    else:
        prm_webserverName = "https-" + corps_appli

    if node_name is None or node_name == "":
        log.severe("ERROR : Missing argument %s" % node_name)
        sys.exit(1)

    # if vip is None or host == "":
    if vip is None:
        log.severe("ERROR : Missing argument %s" % vip)
        sys.exit(1)

    if port is None or port == "":
        log.severe("ERROR : Missing argument %s" % port)
        sys.exit(1)

    node_id = AdminConfig.getid('/Node:%s/' % node_name)
    if node_id == "":
        log.severe("Specified node not correct")
        sys.exit(1)

    if (AdminConfig.getid(
            '/Node:%s/Server:%s/' % (node_name, prm_webserverName)
            ) != ""):
        log.warning(
            "Server Web /Node:" + node_name
            + "/Server:" + prm_webserverName + "/ already exists"
            )
        log.warning("NOT DONE")
    else:
        prm_webConfigurationFilename = prm_IHS_DIR + "/conf/httpd.conf"
        prm_webLogFilenameError = prm_LOGS_IHS_DIR + "/error.log"
        prm_webLogFilenameAccess = prm_LOGS_IHS_DIR + "/access.log"

        log.info("WEB SERVER creation from template IHS")
        log.info("Nom : %s" % prm_webserverName)
        webserver_parent = AdminTask.createWebServer(
            node_name,
            [
                '-name', prm_webserverName,
                '-templateName', 'IHS',
                '-serverConfig', [
                    [
                        port,
                        prm_webInstallRoot,
                        prm_pluginInstallRoot,
                        prm_webConfigurationFilename,
                        "",
                        prm_webLogFilenameError,
                        prm_webLogFilenameAccess,
                        'HTTP'
                    ]
                ]
            ]
            )

        webserver_id = AdminConfig.list('WebServer', webserver_parent)
        if webserver_id == "":
            log.severe("Erreur inattendue, impossible de creer le web server!")
            sys.exit(1)

        AdminConfig.save()

        set_webserver_config(webserver_id, webserver_parent)

        # modification de l'adresse d'ecoute
        server_entries = _splitlines(AdminConfig.list('ServerEntry', node_id))
        for server_entry in server_entries:
            server_name = AdminConfig.showAttribute(server_entry, 'serverName')
            if server_name == prm_webserverName:
                set_host(server_entry, vip)

        log.info("Serveur Web %s initialized" % prm_webserverName)
        AdminConfig.save()
        log.info("DONE")


def create_new_sa(node_name, server_name):
    global prm_WAS_VERSION, prm_serverLogRoot

    log.info(
        "==> Start creation of sa \"" + server_name
        + "\" on node \"" + node_name + "\" from template \"default\""
        )
    new_sa_id = CreateNewSA(node_name, server_name)

    log.info("new_sa_id : %s" % new_sa_id)

    if new_sa_id is not None or new_sa_id != "":
        node_id = AdminConfig.getid('/Node:%s/' % node_name)
        server_id = AdminConfig.getid(
            '/Node:%s/Server:%s/' % (node_name, server_name)
            )
        log.info("Server %s initialized" % server_name)

        server_entries = _splitlines(
            AdminConfig.list('ServerEntry', '%s' % node_id)
            )
        set_server_ports(server_id, server_entries)
        AdminConfig.save()
        config_existing_server(node_name, server_name, prm_serverLogRoot)
        AdminConfig.save()


# -------------------
# Programme Principal
# -------------------

# Application server creation & configuration
if os.environ["CREATE_SA"] == "yes":
    create_new_sa(prm_nodeName, prm_SA_NAME)

# Virtual Host creation
if os.environ["CREATE_VH"] == "yes":
    create_virtualhost(prm_SA_NAME)
    AdminConfig.save()

# Shared libraries creation
if os.environ["CREATE_SHARED_LIBRARIES"] == "yes":
    create_sharedlibs(prm_nodeName, prm_SA_NAME)
    AdminConfig.save()

# Web server creation
if os.environ["CREATE_WEB_SERVER"] == "yes":
    create_webserver(prm_nodeName, prm_SA_NAME, prm_webserverVip,
                     prm_webserverPort, prm_webserverHost, prm_WAS_VERSION)
    AdminConfig.save()

# Node synchronization
log.info("Synchronisation du noeud en cours...")
if SyncNode(prm_nodeName):
    time.sleep(20)
    log.info("Synchronisation du noeud OK.")
else:
    log.severe(
        "Probleme rencontre lors de la tentative de synchronisation : "
        "synchro KO"
        )
    sys.exit(10)
