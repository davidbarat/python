# -*- coding: utf-8 -*-

import os
import sys
import re

sys.path.append(os.environ["ROOT_DIR"] + "/python")
from functions import _noendcar
from functions import *
from customlog import define_logger

# Logging configuration
log = define_logger("analyseProps", "INFO")

propsFile = sys.argv[0]
log.info("Fichier props : %s" % propsFile)
log.info("------------------------------------------")
log.info("Informations sur le serveur d applications")
log.info("------------------------------------------")


def loadFileContents(file):
    fichier = open(file, "r")
    index = 0
    t_Ress = {}
    global flagErreur
    flagErreur = 0

    # ------ Liste des patterns ------
    saPattern = r'^SA_TRIG_NAME_TYPE=.*$'
    appliPattern = r'^APPLICATION=.*$'
    nodePattern = r'^SERVER_NODES=.*$'
    ressPattern = r'^(url|ds|ree)[1-9][0-9]?.*$'
    entryPropName = r'^REE_ENTRY_PROP_NAME.*$'
    entryPropValue = r'^REE_ENTRY_PROP_VALUE.*$'
    realNameAppli = None

    for line in fichier.readlines():
        line = _noendcar(line)

        # ------ Verification existence du SA et application ------
        if re.match(saPattern, line):
            sa = re.sub(r"SA_TRIG_NAME_TYPE=", r"", line)
            log.info("Serveur d applications : %s" % sa)
            saId, node, appli = checkIfSAexists(sa)

            if appli is not None:
                module_appli = re.sub(
                    r"(^SA_)?(^sa-)?(_app$)?(_pres$)?", r"", sa)
                log.info("Application : %s" % appli)
            else:
                log.info(
                    "Aucune application n est installee pour "
                    "le moment (en attente primo-deploiement)"
                    )
                module_appli = None
                realNameAppli = re.sub(
                    r"(^SA_)?(^sa-)?(_app$)?(_pres$)?", r"", sa)

        if re.match(nodePattern, line):
            # ------ Si le SA existe, on recupere le
            # ----- noeud sur lequel il est installe ------
            if node is None:
                node = re.sub(r"SERVER_NODES=", r"", line)
            log.info("Noeud : %s" % node)

        # ------- Identification des ressources
        # ------- (url,ds et ree) eventuelles ------
        if re.match(ressPattern, line):
            liste = line.split('=', 1)
            cle = liste[0].split('.')

            if cle[0] not in t_Ress.keys():
                t_Ress[cle[0]] = {}
            t_Ress[cle[0]][cle[1]] = liste[1]

    if saId is None:
        if os.environ["CREATE_SA"] == "yes":
            log.info("Serveur d applications : %s inexistant" % sa)
            log.info(
                "Celui ci va etre cree avec les infos"
                "fournies dans le fichier props."
                )
        else:
            sys.exit(2)
    else: # If SA exists, delete all resources
        delete_all_ressources(saId)

    log.info("--------------------------------")
    log.info("Informations sur les ressources :")
    log.info("--------------------------------")

    # Definition d'une nouvelle variable
    # A voir si module_appli et realNameAppli peuvent disparaitre...
    if module_appli:
        appliName = module_appli
    else:
        appliName = realNameAppli
    log.fine("appliName = %s" % appliName)

    for nomRess, attributs in t_Ress.items():
        typeRess = re.sub(r"[1-9][0-9]?.*$", r"", nomRess)

        if typeRess == "url":
            action = t_Ress[nomRess]['URL_TYPE_ACTION']
            ressJndiName = t_Ress[nomRess]['URL_JNDI_APPLI']

        elif typeRess == "ds":
            action = t_Ress[nomRess]['JDBC_TYPE_ACTION']
            ressJndiName = t_Ress[nomRess]['JDBC_JNDI_APPLI']

        elif typeRess == "ree":
            action = t_Ress[nomRess]['REE_TYPE_ACTION']
            ressJndiName = t_Ress[nomRess]['REE_ENTRY_JNDI_APPLI']
            allProperties = {}
            for propertyName, propertyValue in attributs.items():
                if re.match(entryPropName, propertyName):
                    indice = re.sub(r"^[a-zA-Z_]*", r"", propertyName)
                    allProperties[propertyName] = [
                        attributs['REE_ENTRY_PROP_NAME%s' % indice],
                        attributs['REE_ENTRY_PROP_VALUE%s' % indice]
                        ]

        else:
            log.severe("ERROR : Le type de la ressource est inconnu !")
            flagErreur = 1

        log.fine("action = %s" % action)
        log.fine("ressJndiName = %s" % ressJndiName)

        if action not in ["view", "create", "update", "delete"]:
            log.severe("ERROR : L action sur la ressource est inconnue !")
            flagErreur = 1

        idRess = find_resource_id(saId, appliName, typeRess, ressJndiName)
        log.fine("idRess = %s" % idRess)

        if idRess is not None:
            log.info(
                "[%s] %s: %s"
                % (action, nomRess, getObjectAttribute(idRess, 'jndiName'))
                )
            log.info("La ressource existe et va etre supprimee.")
            #delete_action(typeRess, idRess)  # Delete si la ressource existe

        else:
            log.info("[%s] %s : %s" % (action, nomRess, ressJndiName))

        if action != "delete":
            # Création de la ressource selon le type
            log.info("Creation de la ressource...")
            if typeRess == "url":
                createUrl(node, sa, ressJndiName, nomRess, t_Ress, appliName)
            elif typeRess == "ds":
                createDs(node, sa, ressJndiName, nomRess, t_Ress, appliName,
                         prm_SHARED_JDBC_DIR)
            elif typeRess == "ree":
                createRee(node, sa, t_Ress[nomRess]['REE_FACTORY_NAME'],
                          t_Ress[nomRess]['REE_CLASS_NAME'], ressJndiName,
                          nomRess, allProperties, appliName)

    if flagErreur == 0:
        # -------- Sauvegarde des modifications -------
        log.info("Debut de la sauvegarde...")
        AdminConfig.save()
        time.sleep(5)
        log.info("Sauvegarde des modifications OK.")

        # ------- Synchronisation des noeuds -------

        log.info("Synchronisation du noeud en cours...")
        if SyncNode(node):
            time.sleep(20)
            log.info("Synchronisation du noeud OK.")

            # ------- Arret / relance du serveur d applications -------

            # stopServer(node,sa)
            # startServer(node,sa)
        else:
            log.severe(
                "Probleme rencontre lors"
                "de la tentative de synchronisation : synchro KO"
                )
            sys.exit(10)
    else:
        log.severe(
            "Des problemes au niveau de certaines"
            "ressources ont ete rencontrees : pas de sauvegarde effectuee."
            )
        sys.exit(3)
    fichier.close()

loadFileContents(propsFile)
